_________________________________________________________________

THINGs ACTIONs Application
_________________________________________________________________

Replace THING and ACTION as per your Project Title

1. Admin Login
	Creation, Deletion, Listing and Filtering Of THING Data
	List THING and THING Details

2. User Login
	Listing and Filtering Of THINGs Data
	List THINGs and THING Details

3. THINGs ACTIONs and Order
	THINGs Selection, Ordering and Shopping Card
		Provision For Payments Acceptance Methods
			Without Payment Gateway Integration

4. Rating The Services/THINGs
5. Preferred THINGs

______________________________________

THINGs
______________________________________

B01. Flights
B02. Buses
B03. Doctors
B04. Cars
B05. Theaters
B06. Movies
B07. CD/Medias
B08. Songs
B09. Bikes
B10. Trips
B11. Finance
B12. Books
B13. Rides
B14. Hotel
B15. Restaurant
B16. Salon and Spa
B17. Sports Facilities
B18. Fitness
B19. Food
B20. House Help
B21. Meeting/Conference/Hall Room
B22. Trains
B23. Online Courses
B24. 

A01. Insurance Policy
A02. Mutual Funds
A03. Shares and Equity
A04. Grocery
A05. Fashion
A06. Couriers
A07. Beverage
A08. Vehicle Parts
A09. Inventory
A10. Medical Tests
A11. Marriage
A12. Sports and Fitness
A13. Electronics
A14. Furnitures
A15. 

______________________________________

ACTIONS
______________________________________
Booking
Renting
Sharing
Purchasing
Planning
Store
Ordering
Investment
Management

_________________________________________________________________

FOR EXAMPLE 

THING 	: Flights
ACTION 	: Booking

Flights Booking Application
_________________________________________________________________


1. Admin Login
	Creation, Deletion, Listing and Filtering Of Flight Data
	List Flights, Flight Details

2. User Login
	Listing and Filtering Of Flight Data
	List Flights, Flight Details

3. Flights Booking and Order
	Flights Selection, Iternary and Travellers Details Input
	Without Payment Gateway Integration

4. Rating The Services
5. Preferred Flights

_________________________________________________________________
_________________________________________________________________
