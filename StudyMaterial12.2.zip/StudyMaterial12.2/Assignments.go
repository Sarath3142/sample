
_____________________________________________________________________

DAY 01
_____________________________________________________________________

	Assignment A0: Reading, Coding and Practice Assignment
		Book: The C Programming Language, 2nd Edition
				By Kernigham and Dennish Richie

			Read, Practice and Reason Following Chapter 
				Chapter 02: Types, Operators and Expressions

_____________________________________________________________________

DAY 02
_____________________________________________________________________

	Assignment A1: Reading, Coding and Practice Assignment
		Tutorial Book:
			GetProgrammingWithGo-PART1.pdf
			Chapters 01 to Chapters 10
				Read All Chapters
				Practice and Experiments Code Examples'
				Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class

_____________________________________________________________________

DAY 03
_____________________________________________________________________

	Assignment A0: Reading, Coding and Practice Assignment [MUST MUST]
		Book: The C Programming Language, 2nd Edition
				By Kernigham and Dennish Richie

			Read, Practice and Reason Following Chapter 
				Chapter: Arrays and Pointers

	Assignment A1: Reading, Coding and Practice Assignment [YESTERDAY]
		Tutorial Book:
			GetProgrammingWithGo-PART1.pdf
			Chapters 01 to Chapters 10
				Read All Chapters
				Practice and Experiments Code Examples'
				Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class

	Assignment A4: Advanced Reading Material [ BRAVE HEARTS!!! ]
		https://en.wikipedia.org/wiki/Single-precision_floating-point_format
		https://en.wikipedia.org/wiki/Double-precision_floating-point_format


_____________________________________________________________________

DAY 04
_____________________________________________________________________

	Assignment A0.1: Reading, Coding and Practice Assignment [MUST MUST]
		Book: The C Programming Language, 2nd Edition
				By Kernigham and Dennish Richie

			Read, Practice and Reason Following Chapter 
				Chapter: Arrays and Pointers

	Assignment A0.2: Coding Assignment [MUST MUST]
		Code C1 : Create 2 Dimentional Array Using Pointers In C
			i.e. Not To Use This Kind Syntax int a[4][5]

	Assignment A1: Reading, Coding and Practice Assignment [YESTERDAY]
		Tutorial Book:
			GetProgrammingWithGo-PART1.pdf
			GetProgrammingWithGo-PART2.pdf
			Chapters 01 to Chapters 20
				Read All Chapters
				Practice and Experiments Code Examples'
				Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class


_____________________________________________________________________

DAY 05
_____________________________________________________________________

	Assignment A0: Reading, Coding and Practice Assignment [MUST MUST]
		Book: The C Programming Language, 2nd Edition
				By Kernigham and Dennish Richie

			Read, Practice and Reason Following Chapter 
				Chapter 05: Arrays and Pointers
				Chapter 06: Structures

	Assignment A1: Reading, Coding and Practice Assignment [YESTERDAY]
		Tutorial Book:
			GetProgrammingWithGo-PART1.pdf
			GetProgrammingWithGo-PART2.pdf
			Chapters 01 to Chapters 20
				Read All Chapters
				Practice and Experiments Code Examples'
				Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class


_____________________________________________________________________

DAY 06
_____________________________________________________________________

	Assignment A0: Reading, Coding and Practice Assignment [MUST MUST]
		Book: The C Programming Language, 2nd Edition
				By Kernigham and Dennish Richie

			Read, Practice and Reason Following Chapter 
				Chapter 05: Arrays and Pointers
				Chapter 06: Structures

	Assignment A1: Reading, Coding and Practice Assignment [YESTERDAY]
			Book: Pro Go, By Adam Freeman
			Chapters 01 to Chapters 10
				Read All Chapters
				Practice and Experiments Code Examples'
				Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class

	Assignment A3: Go Documentation Reading Assignment
		https://pkg.go.dev/fmt
		https://pkg.go.dev/bufio
		

_____________________________________________________________________

DAY 07
_____________________________________________________________________

	Assignment A0: REIVSION Assignment [MUST MUST]
		Book: The C Programming Language, 2nd Edition
				By Kernigham and Dennish Richie

			Read, Practice and Reason Following Chapter 
				Chapter 05: Arrays and Pointers

	Assignment A1: Reading, Coding and Practice Assignment [YESTERDAY]
			Book: Pro Go, By Adam Freeman
			Chapters 01 to Chapters 10
				Read All Chapters
				Practice and Experiments Code Examples'
				Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class

	Assignment A3: Go Documentation Reading Assignment and Coding Examples
		https://pkg.go.dev/strings
		https://pkg.go.dev/strconv


_____________________________________________________________________

DAY 08
_____________________________________________________________________

	Assignment A1: Reading, Coding and Practice Assignment [YESTERDAY]
		Book: Pro Go By Adam Freeman
			Chapter 11: Using Methods and Interfaces
			Chapter 13: Type and Interface Composition
			Chapter 16: String Processing and Regular Expressions 
				Read All Chapters
				Practice and Experiments Code Examples'
				Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class

	Assignment A3: Go Documentation Reading Assignment and Coding Examples
		https://pkg.go.dev/strings
		https://pkg.go.dev/strconv

_____________________________________________________________________

DAY 09
_____________________________________________________________________

	Assignment A1: Reading, Coding and Practice Assignment [YESTERDAY]
		Book: Pro Go By Adam Freeman
			Chapter 11: Using Methods and Interfaces
			Chapter 13: Type and Interface Composition
			Chapter 16: String Processing and Regular Expressions 
			
			Chapter 19: Dates, Times, and Durations	
			Chapter 20: Reading and Writing Data 
			Chapter 22: Working with Files

			These Chapters Contains A Lot More Code Examples

				Read All Chapters
				Practice and Experiments Code Examples'
				Solve All Assignments Mentioned In Each Chapter 

		Book: Learning Go, Oreilly Publication
			Read Following Chapters
				Chapter 08: Errors
				Chapter 09: Modules, Packages, and Imports.		

			Practice and Experiments Chapter Code Examples
			Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class

	Assignment A3: Go Documentation Reading Assignment and Coding Examples
		https://pkg.go.dev/strings
		https://pkg.go.dev/strconv
		https://pkg.go.dev/errors

_____________________________________________________________________

DAY 10
_____________________________________________________________________

	Assignment A1: Reading, Coding and Practice Assignment [YESTERDAY]
		Book: Pro Go By Adam Freeman
			Chapter 19: Dates, Times, and Durations	
			Chapter 20: Reading and Writing Data 
			Chapter 22: Working with Files

			Chapter 21: Working with JSON Data
			Chapter 24: Creating HTTP Servers [ Pages: 627 to 651 ]
			Chapter 25: Creating HTTP Clients

			These Chapters Contains A Lot More Code Examples
			Read All Chapters
			Practice and Experiments Code Examples'
			Solve All Assignments Mentioned In Each Chapter 

		Book: Learning Go, Oreilly Publication
			Read Following Chapters
				Chapter 08: Errors
				Chapter 09: Modules, Packages, and Imports.		

			Practice and Experiments Chapter Code Examples
			Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class

	Assignment A3: Go Documentation Reading Assignment and Coding Examples
		How To Organise Go Code
			http://go.dev/doc/code

_____________________________________________________________________

DAY 11
_____________________________________________________________________

	Assignment A1: Explore and Practice Following Examples 
		StudyMaterial11.1
		└── LearnWeb
		    ├── HelloHTTP
		    ├── HelloRequestParameters
		    ├── GinREST
		    ├── DatabaseAccess

	Assignment A2: Explore and Practice Following Examples 
		StudyMaterial11.2
		└── ProjectRunnersMysql

_____________________________________________________________________

DAY 11:	[[ HOME WORK ]]
_____________________________________________________________________

	Assignment A1: Coding and Practice Assignment
		Code 01: Add CRUD Operations In DatabaseAccess Code
		Code 02: Combine Two Layers DatabaseAccess and GinREST Code
		Code 03: Refactor Code 02 To Bring Controllor Layer
		Code 04: Write End To End REST API With CRUD

	Assignment A2: Reading, Coding and Practice Assignment [YESTERDAY]
		Book: Pro Go By Adam Freeman
			Chapter 21: Working with JSON Data
			Chapter 24: Creating HTTP Servers [ Pages: 627 to 651 ]
			Chapter 25: Creating HTTP Clients

			These Chapters Contains A Lot More Code Examples
			Read All Chapters
			Practice and Experiments Code Examples'
			Solve All Assignments Mentioned In Each Chapter 

_____________________________________________________________________

DAY 12:	PROJECT WORK
_____________________________________________________________________

______________________________________

THINGs ACTIONs Application
______________________________________

1. Admin Login
	Creation, Deletion, Listing and Filtering Of THING Data
	List THING and THING Details

2. User Login
	Listing and Filtering Of THINGs Data
	List THINGs and THING Details

3. THINGs ACTIONs and Order
	THINGs Selection, Ordering and Shopping Card
		Provision For Payments Acceptance Methods
			Without Payment Gateway Integration

4. Rating The Services/THINGs
5. Preferred THINGs

_____________________________________________________________________


https://github.com/amarjitlife/HappiestMinds2024B2
https://github.com/amarjitlife/HappiestMinds2024B2
https://github.com/amarjitlife/HappiestMinds2024B2

