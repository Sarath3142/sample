
package main

import (
    "example.com/hello/first"
    "example.com/hello/second"
    "example.com/hello/firstagain"
)

func main() {
    first.HelloDing()
    second.HelloDong()
    
    //first.helloDing()
    //second.helloDong()
    
    firstthing.HelloTing()
}

// ./main.go:7:5: first redeclared in this block
//     ./main.go:5:5: other declaration of first
// ./main.go:7:5: "example.com/hello/firstagain" imported as first and not used
// ./main.go:17:11: undefined: first.HelloTing
