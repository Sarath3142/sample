
package main

import (
	"fmt"
	"math"
)

//________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE YOUR HANDS!!!

// DUCK TYPING
// In computer programming, 
// Duck Typing is an application of the duck test—
// "If it walks like a duck and it quacks like a duck, 
// then it must be a duck"—
// to determine whether an object can be used for a particular purpose. 

// WHAT TO DO!
type Geometry interface {
	area() float64
	perimeter() float64
}

type Rectangle struct {
	width, height float64
}

type Circle struct {
	radius float64
}

//________________________________________________________________

func ( r Rectangle ) area() float64 {
	return r.width * r.height
}

func ( r Rectangle ) perimeter() float64 {
	return 2 * (r.width + r.height)
}

func ( r Rectangle ) center() (float64, float64) {
	return 0.0, 0.0
}

//________________________________________________________________

func ( c Circle ) area() float64 {
	return math.Pi * c.radius * c.radius
}

func ( c Circle ) perimeter() float64 {
	return 2 * math.Pi * c.radius
}

func ( rect Circle ) center() (float64, float64) {
	return 0.0, 0.0
}

//________________________________________________________________

func calculateGeometryCircle( c Circle ) {
	fmt.Println("Circle: ", c)
	fmt.Println("Circle Area: ", c.area() )
	fmt.Println("Circle Perimeter: ", c.perimeter() )
}

func calculateGeometryRectangle( r Rectangle ) {
	fmt.Println("Rectangle: ", r)
	fmt.Println("Rectangle Area: ", r.area() )
	fmt.Println("Rectangle Perimeter: ", r.perimeter() )
}

// Polymorphic Function
//		Mechanism: Using Interface Type Argument
func calculateGeometry( g Geometry ) {
	fmt.Println("Geometry: ", g)
	fmt.Println("Geometry Area: ", g.area() )
	fmt.Println("Geometry Perimeter: ", g.perimeter() )
}

//________________________________________________________________

type Square struct {
	side float64
}

func ( s Square ) area() float64 {
	return s.side * s.side
}

func ( s Square ) perimeter() float64 {
	return 4 * s.side
}


//________________________________________________________________

func playWithGeometries() {
	circle1 := Circle{ 11 }
	circle2 := Circle{ 22 }
	calculateGeometryCircle( circle1 )
	calculateGeometryCircle( circle2 )

	rectangle1 := Rectangle{ 10, 20 }
	rectangle2 := Rectangle{ 11, 22 }

	calculateGeometryRectangle( rectangle1 )
	calculateGeometryRectangle( rectangle2 )

	calculateGeometry( circle1 )
	calculateGeometry( circle2 )
	calculateGeometry( rectangle1 )
	calculateGeometry( rectangle2 )

	fmt.Println( circle1.center() )
	fmt.Println( rectangle1.center() )

	square1 := Square{ 100 }
	square2 := Square{ 111 }
	calculateGeometry( square1 )
	calculateGeometry( square2 )	
}	

//________________________________________________________________

// type Writer interface {
// 		Write(p []byte) (n int, err error)
// }

// Writer is the interface that wraps the basic Write method.

// type Reader interface {
// 		Read(p []byte) (n int, err error)
// }
// Reader is the interface that wraps the basic Read method.

// Writer is the interface that wraps the basic Write method.
//
// Write writes len(p) bytes from p to the underlying data stream.
// It returns the number of bytes written from p (0 <= n <= len(p))
// and any error encountered that caused the write to stop early.
// Write must return a non-nil error if it returns n < len(p).
// Write must not modify the slice data, even temporarily.
//
// Implementations must not retain p.
// type Writer interface {
// 		Write(p []byte) (n int, err error)
// }

// Closer is the interface that wraps the basic Close method.
//
// The behavior of Close after the first call is undefined.
// Specific implementations may document their own behavior.
// type Closer interface {
// 		Close() error
// }

// Seeker is the interface that wraps the basic Seek method.
//
// Seek sets the offset for the next Read or Write to offset,
// interpreted according to whence:
// [SeekStart] means relative to the start of the file,
// [SeekCurrent] means relative to the current offset, and
// [SeekEnd] means relative to the end
// (for example, offset = -2 specifies the penultimate byte of the file).
// Seek returns the new offset relative to the start of the
// file or an error, if any.
//
// Seeking to an offset before the start of the file is an error.
// Seeking to any positive offset may be allowed, but if the new offset exceeds
// the size of the underlying object the behavior of subsequent I/O operations
// is implementation-dependent.
// type Seeker interface {
// 		Seek(offset int64, whence int) (int64, error)
// }



//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

func main() {	
	fmt.Println("\nFunction: playWithGeometries")
	playWithGeometries()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}

/*
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
*/
