
package learnJava;

import java.util.Arrays;

//________________________________________________________________________

class ArrayDemo {
	public static void playWithArrays() {
		int[] numbers = { 10, 20, 30, 40, 50 };
		int [] numbersCopy = numbers;
		System.out.println("Numbers: " + Arrays.toString(numbers));
		System.out.println("NumbersCopy: " + Arrays.toString(numbersCopy));

		numbers[0] = 99;
		System.out.println("Numbers: " + Arrays.toString(numbers));
		System.out.println("NumbersCopy: " + Arrays.toString(numbersCopy));		
	}
}

// Function: playWithArrays
// Numbers: [10, 20, 30, 40, 50]
// NumbersCopy: [10, 20, 30, 40, 50]
// Numbers: [99, 20, 30, 40, 50]
// NumbersCopy: [99, 20, 30, 40, 50]

//________________________________________________________________________
//________________________________________________________________________
//________________________________________________________________________

public class Experiments {
	public static void main( String args[] ) {
		System.out.println("Function: playWithArrays");
		ArrayDemo.playWithArrays();

		// System.out.println("Function: ");
		// System.out.println("Function: ");
		// System.out.println("Function: ");
		// System.out.println("Function: ");
		// System.out.println("Function: ");
		// System.out.println("Function: ");
		// System.out.println("Function: ");		
	}
}

//________________________________________________________________________
//________________________________________________________________________
