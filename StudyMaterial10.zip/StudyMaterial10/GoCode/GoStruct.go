package main

import (
	"fmt"
	"log"
	"encoding/json"
)
//__________________________________________________________

type Point1 struct {
	X int
	Y int
}

func ScalePoint( point Point1, factor int ) Point1 {
	xx := point.X * factor
	yy := point.Y * factor 
	return Point1{ xx, yy }	
}

func AddPoint( point1 Point1, point2 Point1 ) Point1 {
	xx := point1.X + point2.X
	yy := point1.Y + point2.Y
	return Point1{ xx, yy }	
}

func playWithPointType() {
	point1 := Point1{ 10, 20 }
	point2 := Point1{ 11, 22 }
	point11 := Point1{ 10, 20 }

	fmt.Println( point1, point2, point11 )
	fmt.Println( point1 == point2, point1 == point11, point2 == point11 )

	point3 := ScalePoint( point1, 10 )
	point4 := ScalePoint( point2, 5 )
	fmt.Println( point3, point4)

	point5 := AddPoint( point1, point2 )
	point6 := AddPoint( point11, point2 )
	fmt.Println( point5, point6)
}

//__________________________________________________________

type Circle1 struct {
	X, Y, Radius int
}

type Wheel1 struct {
	X, Y, Radius, Spokes int
}

func playWithCircleAndWheel1() {
	var c Circle1
	c.X = 10
	c.Y = 20
	c.Radius = 50
	fmt.Println( "Circle1 : ", c )

	var w Wheel1
	w.X = 11
	w.Y = 22
	w.Radius = 55
	w.Spokes = 24
	fmt.Println( "Wheel1 : ", w)
}

//__________________________________________________________

// DRY: Don't Repeat Yourself

type Point struct {
	X, Y int
}

type Circle struct {
	Center Point
	Radius int
}

type Wheel struct {
	Circle Circle
	Spokes int
}

func playWithCircleAndWheel() {
	var c Circle
	c.Center.X = 10
	c.Center.Y = 20
	c.Radius = 50
	fmt.Println( "Circle : ", c )

	var w Wheel
	w.Circle.Center.X = 11
	w.Circle.Center.Y = 22
	w.Circle.Radius = 55
	w.Spokes = 24
	fmt.Println( "Wheel : ", w)
}

//__________________________________________________________

type Point2 struct {
	X, Y int
}

type Circle2 struct {
	Point2 // Type Embedding
	Radius int
}

type Wheel2 struct {
	Circle2 //Type Embedding
	Spokes int
}

func playWithCircleAndWheelAgain() {
	var c Circle2
	c.Point2.X = 10
	c.Point2.Y = 20
	c.Radius = 50
	fmt.Println( "Circle2 : ", c )

	var w Wheel2
	w.Circle2.Point2.X = 11
	w.Circle2.Point2.Y = 22
	w.Circle2.Radius = 55
	w.Spokes = 24
	fmt.Println( "Wheel2 : ", w)

	var ww Wheel2 
	ww = Wheel2{ Circle2{ Point2{ 22, 33}, 100 }, 24 }
	fmt.Println( "Wheel2 : ", ww)

	var www Wheel2 
	www = Wheel2{ // Labelled Initialisation List
				Circle2 : Circle2{ 
					Point2 : Point2{ 
						X: 22, 
						Y: 33,
					}, 
					Radius: 100, 
				}, 
				Spokes: 24,
			}
	fmt.Println( "Wheel2 : ", www)

}

//__________________________________________________________

type Movie struct {
	Title string
	Year int
	Color bool
	Actors []string
}

var movies = []Movie {
	{ Title: "Dangal", Year: 2016, Color: true,  Actors: []string{"Aamir Khan", "Babita Phogat", "Geeta Phogat" } },
	{ Title: "Davara", Year: 2024, Color: true,  Actors: []string{"Jr. NTR", "Janvi Kapoor", "Prakash Raj" } },
	{ Title: "Lagaan", Year: 2000, Color: true,  Actors: []string{"Aamir Khan", "Kachara", "Gola" } },
	{ Title: "Om Shanti Om", Year: 2002, Color: true,  Actors: []string{"Shakrukh Khan", "Deepika Padukon", "Arjun Rampal" } },
	{ Title: "Maya Bazaar", Year: 1960, Color: false,  Actors: []string{"Sr. NTR", "Savitari", "ANR" } },
	{ Title: "OG", Year: 2025, Color: true ,  Actors: []string{"Pavan Kalyan", "Prinyaka Mohan", "Arjun Das" } },
	{ Title: "GOAT", Year: 2024 , Color: true,  Actors: []string{"Talapati Vijay", "Sneha", "Trisha" } },
}

func playWithMoviesMarshallingAndUnmarshalling() {
	for index, movie := range movies {
		fmt.Println( index, movie )
	}

	jsonData, err := json.Marshal( movies )
	if err != nil {
		log.Fatalf("JSON Marshalling Failed: %s", err)
	}

	fmt.Println("Marshalled JSON Data:")
	fmt.Printf("%s\n", jsonData)

	var moviesData []Movie 
	if err := json.Unmarshal( jsonData, &moviesData ) ; err != nil {
		log.Fatalf("JSON UNMarshalling Failed: %s", err)
	}

	fmt.Println("UNMarshalled JSON Data:")
	for index, movie := range moviesData {
		fmt.Println( index, movie )
	}

	// Named Structure Type
	// type MovieTitle struct {
	// 		Title string
	// }
	// var moviesTitles []MovieTitle
	
	// Anonymous Structure
	var moviesTitles []struct { Title string }
	if err := json.Unmarshal( jsonData, &moviesTitles ) ; err != nil {
		log.Fatalf("JSON UNMarshalling Failed: %s", err)
	}

	fmt.Println("UNMarshalled JSON Data:")
	for index, movie := range moviesTitles {
		fmt.Println( index, movie )
	}

}


//__________________________________________________________


type MovieAgain struct {
	Title string  	`json:"MovieTitle"`
	Year int 		`json:"ReleasedYear"`
	Color bool
	Actors []string
}

var moviesAgain = []MovieAgain {
	{ Title: "Dangal", Year: 2016, Color: true,  Actors: []string{"Aamir Khan", "Babita Phogat", "Geeta Phogat" } },
	{ Title: "Davara", Year: 2024, Color: true,  Actors: []string{"Jr. NTR", "Janvi Kapoor", "Prakash Raj" } },
	{ Title: "Lagaan", Year: 2000, Color: true,  Actors: []string{"Aamir Khan", "Kachara", "Gola" } },
	{ Title: "Om Shanti Om", Year: 2002, Color: true,  Actors: []string{"Shakrukh Khan", "Deepika Padukon", "Arjun Rampal" } },
	{ Title: "Maya Bazaar", Year: 1960, Color: false,  Actors: []string{"Sr. NTR", "Savitari", "ANR" } },
	{ Title: "OG", Year: 2025, Color: true ,  Actors: []string{"Pavan Kalyan", "Prinyaka Mohan", "Arjun Das" } },
	{ Title: "GOAT", Year: 2024 , Color: true,  Actors: []string{"Talapati Vijay", "Sneha", "Trisha" } },
}

func playWithMoviesMarshallingAndUnmarshallingAgain() {
	for index, movie := range moviesAgain {
		fmt.Println( index, movie )
	}

	jsonData, err := json.Marshal( moviesAgain )
	if err != nil {
		log.Fatalf("JSON Marshalling Failed: %s", err)
	}

	fmt.Println("Marshalled JSON Data:")
	fmt.Printf("%s\n", jsonData)

	var moviesData []MovieAgain 
	if err := json.Unmarshal( jsonData, &moviesData ) ; err != nil {
		log.Fatalf("JSON UNMarshalling Failed: %s", err)
	}

	fmt.Println("UNMarshalled JSON Data:")
	for index, movie := range moviesData {
		fmt.Println( index, movie )
	}

	// Named Structure Type
	// type MovieTitle struct {
	// 		Title string
	// }
	// var moviesTitles []MovieTitle
	
	// Anonymous Structure
	var moviesTitles []struct { Title string }
	if err := json.Unmarshal( jsonData, &moviesTitles ) ; err != nil {
		log.Fatalf("JSON UNMarshalling Failed: %s", err)
	}

	fmt.Println("UNMarshalled JSON Data:")
	for index, movie := range moviesTitles {
		fmt.Println( index, movie )
	}
}

//__________________________________________________________

type tree struct {
	value int
	left *tree
	right *tree
}

func add( t *tree, value int ) * tree {
	if t == nil {
		t = new( tree )
		t.value = value
		return t
	}

	if value < t.value {
		t.left = add( t.left, value )
	} else {
		t.right = add( t.right, value )
	}
	return t
}

func inordreTraversal( values []int, t *tree ) []int {
	if t != nil {
		values = inordreTraversal( values, t.left )
		values = append( values, t.value )
		values = inordreTraversal( values, t.right )		
	}
	return values
}

func playWithTree() {
	data := []int{ 10, 20, 30, 9, 80, 15, 14, 16 }

	var root *tree
	for _, value := range data {
		root = add( root, value )
	}

	fmt.Println( data )
	var values []int
	fmt.Println( inordreTraversal( values, root ) )
}


//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

func main() {
	fmt.Println("\nFunction: playWithPointType")
	playWithPointType()

	fmt.Println("\nFunction: playWithCircleAndWheel1")
	playWithCircleAndWheel1()

	fmt.Println("\nFunction: playWithCircleAndWheel")
	playWithCircleAndWheel()

	fmt.Println("\nFunction: playWithCircleAndWheelAgain")
	playWithCircleAndWheelAgain()

	fmt.Println("\nFunction: playWithMoviesMarshallingAndUnmarshalling")
	playWithMoviesMarshallingAndUnmarshalling()

	fmt.Println("\nFunction: playWithMoviesMarshallingAndUnmarshallingAgain")
	playWithMoviesMarshallingAndUnmarshallingAgain()

	fmt.Println("\nFunction: playWithTree")
	playWithTree()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}

/*
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
*/
