/*
// Compiling Java Code
javac HumanDemo.java -d ClassFiles/

// Running Java Code
java -cp ClassFiles learnJava.HumanDemo
*/

package learnJava;

//__________________________________________________________________________

interface Superpower {
	public void fly();
	public void saveWorld();
}

class Spiderman {
	public void fly() 		{ System.out.println("Fly Like Spiderman!"); }
	public void saveWorld() { System.out.println("Save World Like Spiderman!"); }
}

class Superman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Superman!"); }
	public void saveWorld() { System.out.println("Save World Like Superman!"); }
}

class Heman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Heman!"); }
	public void saveWorld() { System.out.println("Save World Like Heman!"); }
}

class Wonderwoman implements Superpower {
	public void fly() 		{ System.out.println("Fly Like Wonderwoman!"); }
	public void saveWorld() { System.out.println("Save World Like Wonderwoman!"); }
}

class HanumanJi implements Superpower {
	public void fly() 		{ System.out.println("Fly Like HanumanJi!"); }
	public void saveWorld() { System.out.println("Save World Like HanumanJi!"); }
}


// class Human {
// class Human extends Superman {
// class Human extends Heman {	
// class Human extends Wonderwoman {		

// Mechanims: Using Inheritance
class Human extends Spiderman {
	public void fly() 		{ super.fly(); }
	public void saveWorld() { super.saveWorld(); }
}

//__________________________________________________________________________
// Composition Is Alternative To Inheritance
// Mechanims: Using Composition

class HumanBetter {
	// Superman power = null;	
	// Heman power = null;			
	// Wonderwoman power = null;			
	Spiderman power = null;		
	public void fly() 		{ if (power != null) power.fly(); }
	public void saveWorld() { if (power != null) power.saveWorld(); }
}

//__________________________________________________________________________
// DESIGN PRACTICE
//		Always Prefer Compositon Over Inheritance
//		In Composition Substraction Is Possible

// Polymorphic Human
//		Mechanism: Using Composition
class HumanBest {
	Superpower power = null;
	// Spiderman power = null;		
	public void fly() 		{ if (power != null) power.fly(); }
	public void saveWorld() { if (power != null) power.saveWorld(); }
}

//__________________________________________________________________________
//__________________________________________________________________________

public class HumanDemo {
	public static void playWithPowers() {
		Spiderman spiderman = new Spiderman();
		spiderman.fly();
		spiderman.saveWorld();

		Superman superman = new Superman();
		superman.fly();
		superman.saveWorld();

		Heman heman = new Heman();
		heman.fly();
		heman.saveWorld();

		Wonderwoman wonder = new Wonderwoman();
		wonder.fly();
		wonder.saveWorld();
	}

	public static void playWithHuman() {
		Human human = new Human();
		human.fly();
		human.saveWorld();
	}

	public static void playWithHumanBetter() {
		HumanBetter humanbetter = new HumanBetter();
		humanbetter.power = new Spiderman();
		humanbetter.fly();
		humanbetter.saveWorld();
	}

	public static void playWithHumanBest() {
		HumanBest humanbest = new HumanBest();
		// humanbetter.power = new Spiderman();
		humanbest.fly();
		humanbest.saveWorld();

		humanbest.power = new Superman();
		humanbest.fly();
		humanbest.saveWorld();

		humanbest.power = new Heman();
		humanbest.fly();
		humanbest.saveWorld();

		humanbest.power = new Wonderwoman();
		humanbest.fly();
		humanbest.saveWorld();

		humanbest.power = new HanumanJi();
		humanbest.fly();
		humanbest.saveWorld();
	}

	public static void main( String[] args ) {
		System.out.println("\n\nFunction : playWithPowers");
		playWithPowers();

		System.out.println("\n\nFunction : playWithHuman");
		playWithHuman();
		
		System.out.println("\n\nFunction : playWithHumanBetter");
		playWithHumanBetter();

		System.out.println("\n\nFunction : playWithHumanBest");
		playWithHumanBest();

		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
	}
}

