
package main

import (
	"fmt"
	"math"
	"image/color"
)

//________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE YOUR HANDS!!!

type Point struct {
	X, Y float64
}

// Function Taking Two Point Type Arguments
func Distance( p Point, q Point ) float64 {
	return math.Hypot( q.X - p.X, q.Y - p.Y )
}

// In Go
// Method Taking 1 Point Type Arguments
// 		Method or Member Function On Type Point
//		Receiver Type Is Point
func (p Point) Distance( q Point ) float64 {
	fmt.Println("Point: Distance Method Called...")	
	return math.Hypot( q.X - p.X, q.Y - p.Y )
}

/*
// In Go
// func (this Point) Distance( q Point ) float64 {
// 		return math.Hypot( q.X - this.X, q.Y - this.Y )
// }

// In C++
float64 Point::Distance( Point q ) {
	return math.Hypot( q.X - this.X, q.Y - this.Y )
}

// In Java
class Point {
	public float64 Distance( Point q ) {
		return math.Hypot( q.X - this.X, q.Y - this.Y )
	}
}
*/

func playWithFunctionsAndMethods() {
	var point1 = Point{ 10.0, 20.0 	}
	var point2 = Point{ 100.0, 200.0 }

	distance := Distance( point1, point2 )
	fmt.Printf("Distance Between %v And %v: %v\n", point1, point2, distance)

	// Instance Member Function/Method Call
	distance = point1.Distance( point2 )
	fmt.Printf("Distance Between %v And %v: %v\n", point1, point2, distance)
}


//________________________________________________________________

type Path []Point

// Method Taking No Arguments
// 		Method or Member Function On Type Path
//		Receiver Type Is Path
func ( path Path ) Distance() float64 {
	totalDistance := 0.0
	for index := range path {
		if index > 0 {
			totalDistance += path[ index -1 ].Distance( path[ index ] )
		}
	}
	return totalDistance
}

func playWithPathMethods() {
	var point1 = Point{ 10.0, 20.0 	}
	var point2 = Point{ 100.0, 200.0 }
	var point3 = Point{ 50.0, 50.0 	}
	var point4 = Point{ 70.0, 70.0 }

	var path Path = Path{ point1, point2, point3, point4 }
	// Instance Member Function/Method Call
	distance := path.Distance()
	fmt.Printf("Distance For Path %v: %v\n", path, distance)
}

//________________________________________________________________

// Method Taking 1 Argument Of Type float64
// 		Method or Member Function On Type Point
//		Receiver Type Is Point
// Design 01: Reciever Type Object Is Pass By Value
func ( point Point ) ScaleBy1( factor float64 ) {
	point.X = point.X * factor
	point.Y = point.Y * factor	
}

// Design 02: Reciever Type Object Is Pass By Value
func ( point Point ) ScaleBy2( factor float64 ) Point {
	sx := point.X * factor
	sy := point.Y * factor
	return Point{ sx, sy }
}

// Stars Ache Hain!
// Design 03: Reciever Type Object Is Pass By Reference
func ( point * Point ) ScaleBy3( factor float64 ) {
	point.X = point.X * factor
	point.Y = point.Y * factor	
}

func playWithScalePoint() {
	var point1 = Point{ 10.0, 20.0 }
	var point2 = Point{ 4.0, 5.0 }

	fmt.Println("point1 : ", point1)
	fmt.Println("point2 : ", point2)
	point1.ScaleBy1( 5.0 )
	point2.ScaleBy1( 10.0 )
	fmt.Println("point1 : ", point1)
	fmt.Println("point2 : ", point2)

	var point11 = Point{ 10.0, 20.0 }
	var point22 = Point{ 4.0, 5.0 }

	fmt.Println("point11 : ", point11)
	fmt.Println("point22 : ", point22)
	point3 := point11.ScaleBy2( 5.0 )
	point4 := point22.ScaleBy2( 10.0 )
	fmt.Println("Scaled point3 : ", point3 )
	fmt.Println("Scaled point4 : ", point4 )

	var point10 = Point{ 10.0, 20.0 }
	var point20 = Point{ 4.0, 5.0 }

	fmt.Println("point10 : ", point10)
	fmt.Println("point20 : ", point20)
	point10.ScaleBy3( 5.0 )
	point20.ScaleBy3( 10.0 )
	fmt.Println("point10 : ", point10)
	fmt.Println("point20 : ", point20)
}

//________________________________________________________________

type PointAgain struct {
	X, Y int
}

func (point PointAgain) Print() {
	fmt.Printf("PointAgain{%d, %d}\n", point.X, point.Y)
}

type CircleAgain struct {
	PointAgain // Embdedded Type
	Radius int
}

func playWithTypeEmbedding() {
	var c CircleAgain

	c.X = 90
	c.Y = 99
	c.Radius = 11
	fmt.Println("c: ", c)

	var cc CircleAgain

	cc.PointAgain.X = 80
	cc.PointAgain.Y = 88
	cc.Radius = 22
	fmt.Println("cc: ", cc )

	point1 := PointAgain{ 11, 22 }
	point1.Print()
	c.Print()
	cc.Print()
}


//________________________________________________________________

// import "image/color"
type ColoredPoint struct {
	Point // Embedding Point Type
	Color color.RGBA
}

// func ( p ColoredPoint ) Distance( q ColoredPoint ) float64 {
// 		fmt.Println("ColoredPoint: Distance Method Called...")
// 		return math.Hypot( q.X - p.X, q.Y - p.Y )
// }

func playWithColoredPoint() {
	red 	:= color.RGBA{ 255, 0, 0, 255 }
	green 	:= color.RGBA{ 0, 255, 0, 255 }

	cpoint1 := ColoredPoint{ Point{ 10, 20 }, red }
	cpoint2 := ColoredPoint{ Point{  0,  0 }, green }

	// distance1 := cpoint1.Distance( cpoint2 )
	// cannot use cpoint2 (variable of type ColoredPoint) 
	//		as Point value in argument to cpoint1.Distance
	// distance2 := cpoint1.Distance( cpoint2 )
	distance2 := cpoint1.Distance( cpoint2.Point )

	// fmt.Println("Distance Between Colored Points:", distance1)
	fmt.Println("Distance Between Colored Points:", distance2)
}

// We Can Call Methods Of The Embedded Type Point field Using A
// Reciever Type ColoredPoint, even though Colored Point has not
// declared method

//________________________________________________________________
// HOME WORK
// HOME WORK
// HOME WORK

// An IntSet is a set of small non-negative integers.
// 		Its zero value represents the empty set.
type IntSet struct {
	words []uint64
}

// Has reports whether the set contains the non-negative value x.
func (s *IntSet) Has(x int) bool {
	word, bit := x/64, uint(x%64)
	return word < len(s.words) && s.words[word]&(1<<bit) != 0
}

// Add adds the non-negative value x to the set.
func (s *IntSet) Add(x int) {
	word, bit := x/64, uint(x%64)
	for word >= len(s.words) {
		s.words = append(s.words, 0)
	}
	s.words[word] |= 1 << bit
}

// UnionWith sets s to the union of s and t.
func (s *IntSet) UnionWith(t *IntSet) {
	for i, tword := range t.words {
		if i < len(s.words) {
			s.words[i] |= tword
		} else {
			s.words = append(s.words, tword)
		}
	}
}

// String returns the set as a string of the form "{1 2 3}".
func (s *IntSet) String() string {
	var buf bytes.Buffer
	buf.WriteByte('{')
	for i, word := range s.words {
		if word == 0 {
			continue
		}
		for j := 0; j < 64; j++ {
			if word&(1<<uint(j)) != 0 {
				if buf.Len() > len("{") {
					buf.WriteByte(' ')
				}
				fmt.Fprintf(&buf, "%d", 64*i+j)
			}
		}
	}
	buf.WriteByte('}')
	return buf.String()
}

func playWithIntSet() {
	var x, y IntSet
	x.Add(1)
	x.Add(144)
	x.Add(9)
	fmt.Println(x.String()) // "{1 9 144}"

	y.Add(9)
	y.Add(42)
	fmt.Println(y.String()) // "{9 42}"

	x.UnionWith(&y)
	fmt.Println(x.String()) // "{1 9 42 144}"

	fmt.Println(x.Has(9), x.Has(123)) // "true false"
}

func playWithIntSetAgain() {
	var x IntSet
	x.Add(1)
	x.Add(144)
	x.Add(9)
	x.Add(42)

	fmt.Println( &x )         // "{1 9 42 144}"
	fmt.Println( x.String() ) // "{1 9 42 144}"
	fmt.Println(x)          // "{[4398046511618 0 65536]}"
}


//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

func main() {
	fmt.Println("\nFunction: playWithFunctionsAndMethods")
	playWithFunctionsAndMethods()

	fmt.Println("\nFunction: playWithPathMethods")
	playWithPathMethods()

	fmt.Println("\nFunction: playWithScalePoint")
	playWithScalePoint()

	fmt.Println("\nFunction: playWithTypeEmbedding")
	playWithTypeEmbedding()

	fmt.Println("\nFunction: playWithColoredPoint")
	playWithColoredPoint()

	fmt.Println("\nFunction: playWithIntSet")
	playWithIntSet()

	fmt.Println("\nFunction: playWithIntSetAgain")
	playWithIntSetAgain()
	
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}

/*
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
*/
