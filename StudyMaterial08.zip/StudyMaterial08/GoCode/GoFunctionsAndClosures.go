package main

import (
	"fmt"
	"math"
)

//__________________________________________________________

// Following Both Lines Of Code Are Equalivalents
// func division( dividend int, divisor int ) (int, int) {

// Function Taking 2 Arguments Of int Type
//		Returing Tuple Of 2 int Values
func division( dividend, divisor int ) (int, int) {
	if divisor != 0 {
		quotient := dividend / divisor
		remainder := dividend % divisor
		return quotient, remainder
	} else {
		fmt.Println("Error : Divison By Zero!")
		// os.Exit(1)
	}
	return 0, -1
}

//												Named Tuple
func divisionAgain( dividend int, divisor int ) (quotient int, remainder int) { // Outside Context
	// no new variables on left side of :=
	// quotient := 10
	// remainder := 11
	// quotient = 10
	// remainder = 11
	if divisor != 0 { // Inside Context
		// Here quotient And remaidner Are Defined Local To if Block
		//		Local Variables Defined Inside Context
		//				Always Hides Outer Context Variables With Same Name
		quotient := dividend / divisor
		remainder := dividend % divisor
		return quotient, remainder
	} else {
		fmt.Println("Error : Divison By Zero!")
		// os.Exit(1)
	}
	return 0, -1
}

func playWithDivison() {
	q, r := division( 10, 3 )
	fmt.Printf("Quotient: %d Remainder: %d\n", q, r )

	qq, rr := divisionAgain( 10, 3 )
	fmt.Printf("Quotient: %d Remainder: %d\n", qq, rr )	
}


//__________________________________________________________

//									  Named Tuple
//										Defines The Variable Names
func maximumMinimum( numbers []int ) (maximum int, minimum int) {
	// Variables Names Defined In Named Tuple
	//		You Can Use In Code Without Redefining Them.
	maximum = numbers[0]
	minimum = numbers[0]

	// no new variables on left side of :=
	// maximum := numbers[0]
	// minimum := numbers[0]

	for _, number := range numbers[ 1 : ] {
		if number > maximum { maximum = number }
		if number < minimum { minimum = number }
	} 
	return maximum, minimum
}

func playWithMaximumMinimum() {
	numbers := [...]int{ 10, 22, 9, 80, 77, 22, 11, 88, 99, 7, 5 }
	max,  min := maximumMinimum( numbers[:] );
	fmt.Printf("Maximum: %d, Minimum: %d\n", max, min )

	numbersAgain := [...]int{6, 2, 9, 8, 7, 11, 9, 1, 3, 7, 5 }
	max,  min = maximumMinimum( numbersAgain[:] );
	fmt.Printf("Maximum: %d, Minimum: %d\n", max, min )
}

//__________________________________________________________

// Use Multiple Returns Where It Makes Sense
//		Don't Over Use It!
func multipleReturns0() ( int, int, int ) {
	return 10, 11, 12
}

func multipleReturns1( m, n, r int) ( int, int, int, float32 ) {
	return 10, 11, 12, 22.22
}

func playWithMultipleReturns() {
	p, q, r := multipleReturns0()
	fmt.Println(p, q, r )

	a, b, c, d := multipleReturns1(10, 20, 30)
	fmt.Println( a, b, c, d )
}

//__________________________________________________________

func swap(x, y string) (string, string) {
	return y, x
}

func playWithSwapping() {
	a, b := "Hello", "Hi"
	fmt.Println("Values: ", a, b )
	
	a, b = swap(a, b)
	fmt.Println("Values: ", a, b )
}

//__________________________________________________________

func playWithLocalScopeVariables() {
	number := 10
	fmt.Println("number : ", number)

	{
		number := 22
		fmt.Println("number : ", number)
	}
	fmt.Println("number : ", number)

	if number == 10 {
		number := 33

		fmt.Println("number : ", number)		
	}	
	fmt.Println("number : ", number)

	var i int = 99
	fmt.Println("i : ", i)
	for i := 0 ; i < 4 ; i = i + 1 {
		fmt.Println("i :", i)
	}
	fmt.Println("i : ", i)
}

//__________________________________________________________

func doSomething( x int, y int ) int {
	return x + y + 10
}

func playWithFunctionTypes() {
	a, b := 100, 200
	result := 0

	var something func(int, int) int
	something = doSomething

	result = something( a, b )
	fmt.Println("Result : ", result )

	var somethingAgain func (int, int, func(int, int) int ) int
	somethingAgain = calculator
	result = somethingAgain( a, b, sum )
	fmt.Println("Result : ", result )
}

//__________________________________________________________

//What Is The Type Following Functions
// 		func( int, int ) int
func sum(x int, y int) int { return x + y }
func sub(x int, y int) int { return x - y }
func mul(x int, y int) int { return x * y }

// Higher Order Functions
//		Functions Which Takes And/Or Returns Functions

// Polymoprhic Function
//		Mechanims: Higher Order Functions
//				   Passing A Behaviour To Behaviour
//				   Passing A Function To Function
func calculator( x int, y int, operation func(int, int) int ) int {
	return operation(x, y)
}

func playWithHigherOrderFunctions() {
	a, b := 40, 20
	result := 0

	result = calculator(a, b, sum)
	fmt.Println("Result :", result)

	result = calculator(a, b, sub)
	fmt.Println("Result :", result)

	result = calculator(a, b, mul)
	fmt.Println("Result :", result)

	// Anonymous Functions: Closures/Lambda Expression
	//		Function Without Name
	// cannot use 
	// (value of type func(x int, y int) int) as int value in variable declaration
	// var sumClosure int = func( x int, y int ) int { return x + y }
	//What Is The Type Of sumClosure?
	// 		func( int, int ) int	
	var sumClosure func(int, int) int = func( x int, y int ) int { return x + y }
	//What Is The Type Of subClosure?
	// 		func( int, int ) int
	subClosure := func( x int, y int ) int { return x - y }
	//What Is The Type Of mulClosure?
	// 		func( int, int ) int
	mulClosure := func( x int, y int ) int { return x * y }	

	result = calculator(a, b, sumClosure)
	fmt.Println("Result :", result)

	result = calculator(a, b, subClosure)
	fmt.Println("Result :", result)

	result = calculator(a, b, mulClosure)
	fmt.Println("Result :", result)

	something := sum
	fmt.Println("Result :", something(22, 33) )
	fmt.Printf("Type : %T\n", sum )
	fmt.Printf("Type : %T\n", something )

	var somethingAgain func(int, int) int = sum
	fmt.Println("Result :\n", somethingAgain(22, 33) )	
	fmt.Printf("Type : %T\n", somethingAgain )

	somethingMore := calculator
	fmt.Println("Result :\n", somethingMore(22, 33, sum) )
	fmt.Printf("Type : %T\n", somethingMore )

	var somethingOnceMore  func(int, int, func(int, int) int ) int = calculator
	fmt.Println("Result :\n", somethingOnceMore(22, 33, sum) )
	fmt.Printf("Type : %T\n", somethingOnceMore )
}

//__________________________________________________________

func Sphere() func(radius float64) float64 {
	volumeClosure := func( radius float64 ) float64 {
		volume := 4 / 3 * math.Pi * radius * radius * radius
		return volume
	}

	return volumeClosure
}

func playWithHigherOrderFunctionsAgain() {
	// What Is The Type Of something?
	//		func (float64 ) float64
	something := Sphere()
	fmt.Println( something )
	fmt.Printf("Type %T\n", something )
	// What Is The Type Of somethingAgain?
	//		func() func (float64 ) float64
	somethingAgain := Sphere
	fmt.Println( somethingAgain )
	fmt.Printf("Type %T\n", somethingAgain )
	// What Is The Type Of somethingMore?
	//		float64
	somethingMore := something( 99.99 )
	fmt.Println( somethingMore )
	fmt.Printf("Type %T\n", somethingMore )	
}

//__________________________________________________________

func firstFunction() 	{ fmt.Println("First Function Called...") }
func secondFunction() 	{ fmt.Println("Second Function Called...") }
func thirdFunction() 	{ fmt.Println("Third Function Called...") }

func playWithDeferFunctions() {
	// defer Keyword Delays Exectution Of Statement
	//		Till End Of Enclosing Function
	defer firstFunction()
	secondFunction()
	defer thirdFunction()
// defer Statements Are Called Just 
//		Before Return Out Of Enclosing Functions
//		Multiple Defers Are Called Last In First Out Order
}

//__________________________________________________________

func someFunction() (some int) {
	defer func() { some++ }()
	return 1
}

func playWithDeferFunctionsAgain() {
	result := someFunction()
	fmt.Println("Result : ", result)
}

// The behavior of defer statements is straightforward and predictable. 
// There are three simple rules:
// 	1. A deferred function’s arguments are evaluated when 
//		the defer statement is evaluated.
//  2. Deferred function calls are executed in Last In First Out Order 
		// after the surrounding function returns.
// 3. Deferred functions may read and assign to the returning 
// 		function’s named return values.


//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

func main() {
	fmt.Println("\nFunction: playWithDivison")
	playWithDivison()

	fmt.Println("\nFunction: playWithMaximumMinimum")
	playWithMaximumMinimum()

	fmt.Println("\nFunction: playWithMultipleReturns")
	playWithMultipleReturns()

	fmt.Println("\nFunction: playWithSwapping")
	playWithSwapping()

	fmt.Println("\nFunction: playWithLocalScopeVariables")
	playWithLocalScopeVariables()

	fmt.Println("\nFunction: playWithFunctionTypes")
	playWithFunctionTypes()

	fmt.Println("\nFunction: playWithHigherOrderFunctions")
	playWithHigherOrderFunctions()

	fmt.Println("\nFunction: playWithHigherOrderFunctionsAgain")
	playWithHigherOrderFunctionsAgain()

	fmt.Println("\nFunction: playWithDeferFunctions")
	playWithDeferFunctions()

	fmt.Println("\nFunction: playWithDeferFunctionsAgain")
	playWithDeferFunctionsAgain()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}

/*
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
*/
