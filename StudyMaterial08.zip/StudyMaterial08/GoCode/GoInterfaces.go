
package main

import (
	"fmt"
	"math"
)

//________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE YOUR HANDS!!!

// DUCK TYPING
// In computer programming, 
// Duck Typing is an application of the duck test—
// "If it walks like a duck and it quacks like a duck, 
// then it must be a duck"—
// to determine whether an object can be used for a particular purpose. 

// WHAT TO DO!
type Geometry interface {
	area() float64
	perimeter() float64
}

type Rectangle struct {
	width, height float64
}

type Circle struct {
	radius float64
}

//________________________________________________________________

func ( r Rectangle ) area() float64 {
	return r.width * r.height
}

func ( r Rectangle ) perimeter() float64 {
	return 2 * (r.width + r.height)
}

func ( r Rectangle ) center() (float64, float64) {
	return 0.0, 0.0
}

//________________________________________________________________

func ( c Circle ) area() float64 {
	return math.Pi * c.radius * c.radius
}

func ( c Circle ) perimeter() float64 {
	return 2 * math.Pi * c.radius
}

func ( rect Circle ) center() (float64, float64) {
	return 0.0, 0.0
}

//________________________________________________________________

func calculateGeometryCircle( c Circle ) {
	fmt.Println("Circle: ", c)
	fmt.Println("Circle Area: ", c.area() )
	fmt.Println("Circle Perimeter: ", c.perimeter() )
}

func calculateGeometryRectangle( r Rectangle ) {
	fmt.Println("Rectangle: ", r)
	fmt.Println("Rectangle Area: ", r.area() )
	fmt.Println("Rectangle Perimeter: ", r.perimeter() )
}

// Polymorphic Function
//		Mechanism: Using Interface Type Argument
func calculateGeometry( g Geometry ) {
	fmt.Println("Geometry: ", g)
	fmt.Println("Geometry Area: ", g.area() )
	fmt.Println("Geometry Perimeter: ", g.perimeter() )
}

//________________________________________________________________

type Square struct {
	side float64
}

func ( s Square ) area() float64 {
	return s.side * s.side
}

func ( s Square ) perimeter() float64 {
	return 4 * s.side
}


//________________________________________________________________

func playWithGeometries() {
	circle1 := Circle{ 11 }
	circle2 := Circle{ 22 }
	calculateGeometryCircle( circle1 )
	calculateGeometryCircle( circle2 )

	rectangle1 := Rectangle{ 10, 20 }
	rectangle2 := Rectangle{ 11, 22 }

	calculateGeometryRectangle( rectangle1 )
	calculateGeometryRectangle( rectangle2 )

	calculateGeometry( circle1 )
	calculateGeometry( circle2 )
	calculateGeometry( rectangle1 )
	calculateGeometry( rectangle2 )

	fmt.Println( circle1.center() )
	fmt.Println( rectangle1.center() )

	square1 := Square{ 100 }
	square2 := Square{ 111 }
	calculateGeometry( square1 )
	calculateGeometry( square2 )	
}	

//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

func main() {	
	fmt.Println("\nFunction: playWithGeometries")
	playWithGeometries()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}

/*
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
*/
