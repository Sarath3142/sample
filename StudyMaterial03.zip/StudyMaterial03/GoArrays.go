
package main

import "fmt"

//__________________________________________________________

func playWithArrays() {
	var a[4]int

	fmt.Println( a )
	// [(0, 0), (1, 0), (2, 0), (3,0 )]
	for i, value := range a {
		fmt.Println( i, value )
	}

	fmt.Println( a[0] )
	fmt.Println( a[1] )
	fmt.Println( a[ len( a ) - 1 ])

	for _, value := range a {
		fmt.Println( value )
	}

	for index := range a {
		fmt.Println( index, a[ index ] )
	}
}

//__________________________________________________________

func playWithArraysAgain() {
						// Initialisation List
	var q [5]int = [5]int{ 10, 20, 30, 40, 50 }
	var r [5]int = [5]int{ 10, 20, 30 }

	fmt.Println("Array q Length: ", len( q ) )
	fmt.Println("Array r Length: ", len( r ) )

	fmt.Printf("Array q Type: %T \n", q )
	fmt.Printf("Array r Type: %T \n", r )

	for index, value := range q {
		fmt.Println("At Index: ", index, " Value: ", value )
	}	
	// ... Means Deduce Size From Initialisation List
	s := [...]int{10, 20, 30, 40, 99, 100, 111}
	fmt.Println("Array s:", s )
	fmt.Println("Array s Length: ", len( s ) )
	fmt.Printf("Array s Type: %T \n", s )

	for index, value := range s {
		fmt.Println("At Index: ", index, " Value: ", value )
	}	

	aa := [2]int { 10, 20 }
	bb := [...]int {10, 20}
	cc := [2]int { 10, 20 }

	fmt.Println("aa == bb : ", aa == bb )
	fmt.Println("aa == cc : ", aa == cc )
	fmt.Println("cc == bb : ", cc == bb )

	aaa := [2]int { 10, 20 }
	bbb := [3]int { 10, 20 }

	fmt.Println( aaa, bbb )
	// invalid operation: aaa == bbb 
	//		(mismatched types [2]int and [3]int)
	// fmt.Println("aaa == bbb : ", aaa == bbb )
	// Initialisation List With Indexes For Members
	someArray := [...]int { 0 : 11, 3 : 33, 7 : 77 }
	fmt.Println("Array someArray:", someArray )
	fmt.Println("Array someArray Length: ", len( someArray ) )
	fmt.Printf("Array someArray Type: %T \n", someArray )

	someArrayAgain := [...]int { 99 : -1 }
	fmt.Println("Array someArrayAgain:", someArrayAgain )
	fmt.Println("Array someArrayAgain Length: ", len( someArrayAgain ) )
	fmt.Printf("Array someArrayAgain Type: %T \n", someArrayAgain )

	var some [4]float64 = [4]float64{ 99.90, 88.88, 111, 99 }
	fmt.Println("Array some:", some )
	fmt.Println("Array some Length: ", len( some ) )
	fmt.Printf("Array some Type: %T \n", some )

	var something = [4]string { "Ding", "Ting", "Tong", "Dong" }
	fmt.Println("Array something:", something )
	fmt.Println("Array something Length: ", len( something ) )
	fmt.Printf("Array something Type: %T \n", something )
}

//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

func main() {
	fmt.Println("\nFunction: playWithArrays")
	playWithArrays()

	fmt.Println("\nFunction: playWithArraysAgain")
	playWithArraysAgain()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}

/*
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
*/

