
package main

import "fmt"

//__________________________________________________________

func playWithArrayAndSlices() {
	a := [...]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 }
	fmt.Println("Array a: ", a)
	fmt.Printf("Array Type: %T\n", a)

	some1 := a[ 0 : 4 ]
	fmt.Println("Slice some1: ", some1 )
	fmt.Printf("Slice Type: %T\n", some1)
	fmt.Printf("Slice Len: %d Cap: %d\n", len(some1), cap(some1))

	some2 := a[ 4 : 9 ]
	fmt.Println("Slice some2: ", some2 )
	fmt.Printf("Slice Type: %T\n", some2)
	fmt.Printf("Slice Len: %d Cap: %d\n", len(some2), cap(some2))

	some3 := a[  : 5 ]
	fmt.Println("Slice some3: ", some3 )
	fmt.Printf("Slice Type: %T\n", some3)
	fmt.Printf("Slice Len: %d Cap: %d\n", len(some3), cap(some3))

	some4 := a[ 6 :  ]
	fmt.Println("Slice some4: ", some4 )
	fmt.Printf("Slice Type: %T\n", some4)
	fmt.Printf("Slice Len: %d Cap: %d\n", len(some4), cap(some4))

	some5 := a[ : ]
	fmt.Println("Slice some5: ", some5 )
	fmt.Printf("Slice Type: %T\n", some5)
	fmt.Printf("Slice Len: %d Cap: %d\n", len(some5), cap(some5))
}

//__________________________________________________________
// In Go
//		By Default Arrays Are Pass By Value

// In C/C++/Java/Python
//		By Default Arrays Are Pass By Reference

func changeArray( some [5]int ) {
	fmt.Println("Inside changeArray:: some: ", some)	
	for index, _ := range some {
		some[ index ] = 99
	}
	fmt.Println("Inside changeArray:: some: ", some)	
}

func changeArrayAgain( some [5]int ) {
	var someNew [5]int = [5]int{ 11, 11, 11, 11, 11 }
	some = someNew
}

// Array Pass By Reference Using Reference
func changeArrayMore( someAddress *[5]int ) {
	for index, _ := range someAddress {
		someAddress[ index ] = 99
	}
}

// Array Pass By Reference Using Slice
func changeArrayOnceMore( someSlice []int ) {
	for index, _ := range someSlice {
		someSlice[ index ] = 88
	}
}

func playWithArrayAndSlicessAgain() {
	var numbers [5]int = [5]int{ 10, 20, 30, 40, 50 }
	fmt.Println("Numbers: ", numbers)
	changeArray( numbers )
	fmt.Println("Numbers: ", numbers)
	changeArrayAgain( numbers )
	fmt.Println("Numbers: ", numbers)
	changeArrayMore( &numbers ) // Passing Address/Reference Of Array
	fmt.Println("Numbers: ", numbers)
	changeArrayOnceMore( numbers[ : ] ) // Passing Slice Of Array
	fmt.Println("Numbers: ", numbers)
}
// Function: playWithArraysOnceAgain
// Numbers:  [10 20 30 40 50]
// Numbers:  [10 20 30 40 50]
// Numbers:  [10 20 30 40 50]
// Numbers:  [99 99 99 99 99]

//__________________________________________________________

func playWithArrays() {
	var numbers [5]int = [5]int { 10, 20, 30, 40, 50 }
	// Array Assignment i.e. It's Value Assignment
	numbersCopy := numbers

	fmt.Println("Numbers: ", numbers)
	fmt.Println("numbersCopy: ", numbersCopy)

	numbers[0] = 99
	fmt.Println("Numbers: ", numbers)
	fmt.Println("numbersCopy: ", numbersCopy)
}

//__________________________________________________________

func reverse( s []int ) {
	for i, j := 0, len( s ) - 1 ; i < j ; i, j = i + 1, j - 1 {// i++, j-- {
		s[i], s[j] = s[j], s[i]
	}
}

func playWithArraysAndSlices() {
	a := [...]int{10, 20, 30, 40, 50, 60, 70, 80, 90, 99}
	fmt.Println("Array a: ", a)

	some1 := a[ 0 : 4 ]
	reverse( some1 )
	fmt.Println("Array a: ", a)

	some2 := a[ 4 : 9 ]
	reverse( some2 )
	fmt.Println("Array a: ", a)

	some3 := a[  :  ]
	reverse( some3 )
	fmt.Println("Array a: ", a)
}

//__________________________________________________________

func printCommon( summer []string, quater []string ) {
	for _, summerMonth := range summer {
		for _, quaterMonth := range quater {
			if summerMonth == quaterMonth {
				fmt.Println("%s Month Appear In Both!", summer, quater)
			}
		}
	}
}

// func slicesEqual( x []string, y []string ) bool
func slicesEqual( x, y []string ) bool {
	if len( x ) != len( y ) { return false }

	for index := range x {
		if x[index] != y[index] { return false }
	}

	return true
}

func playWithSlices() {
	months := [...]string {
		1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun",
		7: "Jul", 8: "Aug", 9: "Sep", 10:"Oct", 11:"Nov", 12:"Dec",
	}

	quater2 := months[ 4 : 7 ]
	summers := months[ 6 : 9 ]
	fmt.Println( months )
	fmt.Println( quater2 )
	fmt.Println( summers )	
	printCommon( summers, quater2 )

	firstThree := months[ 1 : 4 ]
	quater1    := months[ 1 : 4]
	// invalid operation: firstThree == quater1 
	//		(slice can only be compared to nil)
	// equalResult := firstThree == quater1
	equalResult := slicesEqual( firstThree, quater1 )
	fmt.Println(equalResult)
}

//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

func main() {
	fmt.Println("\nFunction: playWithArrayAndSlices")
	playWithArrayAndSlices()

	fmt.Println("\nFunction: playWithArrayAndSlicessAgain")
	playWithArrayAndSlicessAgain()

	fmt.Println("\nFunction: playWithArrays")
	playWithArrays()

	fmt.Println("\nFunction: playWithArraysAndSlices")
	playWithArraysAndSlices()

	fmt.Println("\nFunction: playWithSlices")
	playWithSlices()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}

/*
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
*/

