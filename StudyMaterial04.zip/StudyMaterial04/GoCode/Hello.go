/*
To Directly Run Go Program
go run Hello.go

To Generate Executable File From Go Program
go build Hello.go

To Run Generated Go Command
./Hello
*/
package main

import "fmt"

func main() {
	fmt.Println("Hello World!!!")
}

