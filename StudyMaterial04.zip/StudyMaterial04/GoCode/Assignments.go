
_____________________________________________________________________

DAY 01
_____________________________________________________________________

	Assignment A0: Reading, Coding and Practice Assignment
		Book: The C Programming Language, 2nd Edition
				By Kernigham and Dennish Richie

			Read, Practice and Reason Following Chapter 
				Chapter 02: Types, Operators and Expressions

_____________________________________________________________________

DAY 02
_____________________________________________________________________

	Assignment A1: Reading, Coding and Practice Assignment
		Tutorial Book:
			GetProgrammingWithGo-PART1.pdf
			Chapters 01 to Chapters 10
				Read All Chapters
				Practice and Experiments Code Examples'
				Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class

_____________________________________________________________________

DAY 03
_____________________________________________________________________

	Assignment A0: Reading, Coding and Practice Assignment [MUST MUST]
		Book: The C Programming Language, 2nd Edition
				By Kernigham and Dennish Richie

			Read, Practice and Reason Following Chapter 
				Chapter: Arrays and Pointers

	Assignment A1: Reading, Coding and Practice Assignment [YESTERDAY]
		Tutorial Book:
			GetProgrammingWithGo-PART1.pdf
			Chapters 01 to Chapters 10
				Read All Chapters
				Practice and Experiments Code Examples'
				Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class

	Assignment A4: Advanced Reading Material [ BRAVE HEARTS!!! ]
		https://en.wikipedia.org/wiki/Single-precision_floating-point_format
		https://en.wikipedia.org/wiki/Double-precision_floating-point_format


_____________________________________________________________________

DAY 04
_____________________________________________________________________

	Assignment A0.1: Reading, Coding and Practice Assignment [MUST MUST]
		Book: The C Programming Language, 2nd Edition
				By Kernigham and Dennish Richie

			Read, Practice and Reason Following Chapter 
				Chapter: Arrays and Pointers

	Assignment A0.2: Coding Assignment [MUST MUST]
		Code C1 : Create 2 Dimentional Array Using Pointers In C
			i.e. Not To Use This Kind Syntax int a[4][5]

	Assignment A1: Reading, Coding and Practice Assignment [YESTERDAY]
		Tutorial Book:
			GetProgrammingWithGo-PART1.pdf
			GetProgrammingWithGo-PART2.pdf
			Chapters 01 to Chapters 20
				Read All Chapters
				Practice and Experiments Code Examples'
				Solve All Assignments Mentioned In Each Chapter 

	Assignment A2: Practice And Revise Code Examples 
		All Code Examples Done In Class
		Extend and Experiments Code Examples Done In Class

_____________________________________________________________________
_____________________________________________________________________
_____________________________________________________________________

https://github.com/amarjitlife/HappiestMinds2024B2
https://github.com/amarjitlife/HappiestMinds2024B2
https://github.com/amarjitlife/HappiestMinds2024B2


