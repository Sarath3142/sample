
package main

import (
    "log"
    "time"
    "gorm.io/driver/mysql"
    "gorm.io/gorm"
)

const (
	dsn = "amarjit:amarjit@tcp(127.0.0.1:3306)/crudwithgorm?charset=utf8mb4&parseTime=True&loc=Local"
    defaultLimit = 100
)
// Order represents the orders table in the database

type Order struct {
    ID     int64        `gorm:"primaryKey;autoIncrement"`
    Items  []*OrderItem `gorm:"foreignKey:OrderID;references:ID;constraint:OnDelete:CASCADE"`
    Status string       `gorm:"not null"`
}
// OrderItem represents the order_items table in the database

type OrderItem struct {
    OrderID  int64   `gorm:"primaryKey"`
    ItemID   int64   `gorm:"primaryKey"`
    Quantity uint    `gorm:"not null"`
    Price    float64 `gorm:"not null"`
}

func createOrder(db *gorm.DB, order *Order) (err error) {
    tx := db.Begin()

    if tx.Error != nil {
        return tx.Error
    }
    defer func() {
        if r := recover(); r != nil || err != nil {
            tx.Rollback()
        } else {
            tx.Commit()
        }
    }()
    err = tx.Create(order).Error
    if err != nil {
        return err
    }
    return nil
}

func updateOrder(db *gorm.DB, order *Order) (err error) {
    tx := db.Begin()
    if tx.Error != nil {
        return tx.Error
    }
    defer func() {
        if r := recover(); r != nil || err != nil {
            tx.Rollback()
        } else {
            tx.Commit()
        }
    }()
    return tx.Save(order).Error
}

func deleteOrder(db *gorm.DB, orderID int64) error {
    return db.Delete(&Order{}, orderID).Error
}

type listCondition struct {
    Limit  int
    Offset int
}

func listOrders(db *gorm.DB, cond listCondition) (items []*Order, total int, err error) {
    if cond.Limit <= 0 {
        cond.Limit = defaultLimit
    }
    if cond.Offset < 0 {
        cond.Offset = 0
    }
    var count int64
    var orders []*Order
    err = db.Model(&Order{}).Limit(cond.Limit).Offset(cond.Offset).Order("id DESC").Count(&count).Find(&orders).Error
    if err != nil {
        return nil, 0, err
    }
    return orders, int(count), nil
}

func getOrderByID(db *gorm.DB, orderID int64) (*Order, error) {
    order := new(Order)
    err := db.Preload("Items").First(order, orderID).Error
    if err != nil {
        return nil, err
    }
    return order, nil
}

//__________________________________________________________________________
//__________________________________________________________________________
//__________________________________________________________________________
//__________________________________________________________________________

func main() {
    db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
    if err != nil {
        log.Fatalf("open db error: %v", err)
    }
    // Get the underlying sql.DB object to close the connection later
    sqlDB, err := db.DB()
    if err != nil {
        log.Printf("get db error: %v", err)
        return
    }
    defer sqlDB.Close()
    sqlDB.SetMaxOpenConns(500)
    sqlDB.SetMaxIdleConns(100)
    sqlDB.SetConnMaxLifetime(5 * time.Minute)
    // Ping the database to check if the connection is successful
    err = sqlDB.Ping()
    if err != nil {
        log.Printf("ping db error: %v", err)
        return
    }
    log.Println("Database connection successful")
    // Perform auto migration
    err = db.AutoMigrate(&Order{}, &OrderItem{})
    if err != nil {
        log.Printf("auto migrate error: %v", err)
        return
    }
    log.Println("Auto migration completed")
    // Create a new order
    order := &Order{
        Status: "Pending",
        Items: []*OrderItem{
            {ItemID: 1, Quantity: 2, Price: 10.0},
            {ItemID: 2, Quantity: 1, Price: 20.0},
        },
    }
    err = createOrder(db, order)
    if err != nil {
        log.Printf("create order error: %v", err)
        return
    }
    log.Println("Order created successfully with ID:", order.ID)
    // List all orders
    orders, total, err := listOrders(db, listCondition{
        Limit:  10,
        Offset: 0,
    })
    if err != nil {
        log.Printf("list orders error: %v", err)
        return
    }
    for _, o := range orders {
        log.Printf("order: %+v\n", o)
    }
    log.Printf("total orders: %d\n", total)
    // Get order by ID
    orderID := order.ID
    order, err = getOrderByID(db, orderID)
    if err != nil {
        log.Printf("get order by ID error: %v", err)
        return
    }
    log.Printf("order with ID %d: %+v\n", orderID, order)
    // Update order status
    order.Status = "Completed"
    err = updateOrder(db, order)
    if err != nil {
        log.Printf("update order error: %v", err)
        return
    }
    log.Printf("Order updated successfully with ID:", order.ID)
    // Delete order
    err = deleteOrder(db, order.ID)
    if err != nil {
        log.Printf("delete order error: %v", err)
        return
    }
    log.Println("Order deleted successfully with ID:", order.ID)
}

//__________________________________________________________________________
//__________________________________________________________________________

// mysql> create database crudwithgorm;

//__________________________________________________________________________
