
package second

import "fmt"

func HelloDong() {
    fmt.Println("Hello Dong!!!")
}

func helloDong() {
    fmt.Println("hello Dong!!!")
}

