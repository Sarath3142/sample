/*
To Directly Run Go Program
go run GoFoundation.go

To Generate Executable File From Go Program
go build GoFoundation.go

To Run Generated Go Command
./GoFoundation
*/
package main

import "fmt"

//__________________________________________________________

func helloWorld() {
	fmt.Println("Hello World!!!")
}

//__________________________________________________________

// Constant
const boilingF = 212.0
const boilingCentigrade = 100

// Variable
var ff = 99
var cc = 88

func fToC( f float64 ) float64 {
	return ( f  - 32 ) * 5 / 9
}

func playWithConstantsAndVariables() {
	var f = boilingF
	var c = ( f  - 32 ) * 5 / 9 

	fmt.Printf("\nBoiling Point: %g Farenheit:", f)
	fmt.Printf("\nBoiling Point: %g Centrigrade:", c)

	var boilingC = fToC( boilingF )
	fmt.Printf("\nBoiling Point: %g Centrigrade:", boilingC)

	const first, second = 99.99, 88.88
	fmt.Printf("\nFirst: %g, Second: %g", first, second)

	fmt.Printf("\nVariables Outside: %d %d", ff, cc )
}

//__________________________________________________________

type Celsius 	float64
type Fahrenheit float64

const (
	BoilingC 		Celsius = 100.0
	FreezingC 		Celsius = 0.0
	AbsoluteZeroC 	Celsius = -273.15
	FreezingF 		Fahrenheit = 0.05
)

func playWithTypes() {
	var ff, gg = 11.11, 22.22
	var rr = ff + gg
	fmt.Println("Result: ", rr )

	var ffAgain Celsius = 11.11
	var ggAgain Fahrenheit = 22.22
	// invalid operation: ffAgain + ggAgain 
	//		(mismatched types Celsius and Fahrenheit)
	// var rrAgain = ffAgain + ggAgain

	// Go Promotes Explicit Type Casting
	var rrAgain float64 = float64( ffAgain ) + float64( ggAgain )
	fmt.Println("Values Again: ", ffAgain, ggAgain )
	fmt.Println("Result Again: ", rrAgain )
}

//__________________________________________________________


func playWithTypesData() {
	var i int32 = 111
	var j int64 = 222

// ./GoFoundation.go:84:10: invalid operation: i + j 
//		(mismatched types int32 and int64)
	// var some int64 = i + j

	var some int64 = int64( i ) + j
	fmt.Println( i, j, some )

	var ff float32 = 11.11
	var gg float64 = 22.22

// ./GoFoundation.go:90:8: invalid operation: ff + gg 
//		(mismatched types float32 and float64)
	// var zz float64 = ff + gg
	var zz float64 = float64( ff ) + gg	
	fmt.Println( ff, gg, zz )
}

//__________________________________________________________

// func fToC( f float64 ) float64 {
// 	return ( f  - 32 ) * 5 / 9
// }
// Better APIs: 
//		1. Clarifies Intent Of Code/Programmer
//		2. Captures Domain Knowledge
//		3. Code Itself Documentation

func FToC( f Fahrenheit ) Celsius {
	return Celsius( ( f  - 32 ) * 5 / 9 )	
}

func CToF( c Celsius ) Fahrenheit {
	return Fahrenheit( c * 9 / 5 + 32 )
}

func playWithTypesAgain() {
	 var result = FToC( FreezingF )
	 fmt.Println("Result :", result)

	 var resultAgain = CToF( FreezingC )
	 fmt.Println("ResultAgain :", resultAgain)	 

	 var resultOnceAgain = FToC( 212.15 )
	 fmt.Println("ResultOnceAgain :", resultOnceAgain)	 	 

	 var temperature float64 = 212.15
	 // cannot use temperature 
	 // (variable of type float64) as Fahrenheit value in argument to FToC
	 // var resultOnceMore = FToC( temperature )
	 var resultOnceMore = FToC( Fahrenheit( temperature )  )
	 fmt.Println("ResultOnceMore :", resultOnceMore)	 	 
}

//__________________________________________________________

func playWithTypesAndDefaultValues() {
	var a int
	var a8 int8
	var a16 int16
	var a32 int32
	var a64 int64
	fmt.Println(a, a8, a16, a32, a64)

	var ua uint
	var ua8 uint8
	var ua16 uint16
	var ua32 uint32
	var ua64 uint64
	fmt.Println( ua, ua8, ua16, ua32, ua64)

	var f1 float32
	var f2 float64
	fmt.Println( f1, f2 )

	//Short Hand Syntax To Define Variable
	//	1. Type Will Inferred From RHS Value
	//	2. Inferred Type Will Be Binded To LHS (Identifier)
	aa := 99
	fmt.Println("Value: ", aa )
	fmt.Printf("Type Is: %T\n", aa )

	ff := 99.99
	fmt.Println("Value: ", ff )
	fmt.Printf("Type Is: %T\n", ff )

	var some string
	fmt.Println(":", some, ":")

	greeting := "Good Evening!"
	fmt.Println("Value: ", greeting )
	fmt.Printf("Type Is: %T\n", greeting )	

	var b bool
	fmt.Println( b )

	var c1 complex64
	fmt.Println( c1 )

	var c2 complex128
	fmt.Println( c2 )
}


//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

func main() {
	fmt.Println("\nFunction: helloWorld")
	helloWorld()

	fmt.Println("\nFunction: playWithConstantsAndVariables")
	playWithConstantsAndVariables()

	fmt.Println("\nFunction: playWithTypes")
	playWithTypes()

	fmt.Println("\nFunction: playWithTypesData")
	playWithTypesData()

	fmt.Println("\nFunction: playWithTypesAgain")
	playWithTypesAgain()

	fmt.Println("\nFunction: playWithTypesAndDefaultValues")
	playWithTypesAndDefaultValues()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}

/*
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
*/

