
import math

#________________________________________________________________
# EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE YOUR HANDS!!!

class Point:
	def __init__(self, x, y):
		self.X = x
		self.Y = y	

	def Distance(self, other):
		deltaX = self.X - other.X
		deltaY = self.Y - other.Y

		return math.sqrt( (deltaX * deltaX) + (deltaY * deltaY) )

	def ScaleBy(self, factor):
		self.X = self.X * factor		
		self.Y = self.Y * factor

	def Print(self):
		print( self.X, self.Y )

def playWithPathMethods():
	point1 = Point( 10.0, 20.0 )
	point2 = Point( 4.0, 5.0 )

	point1.Print()
	point2.Print()

	point1.ScaleBy( 5.0 )
	point2.ScaleBy( 10.0 )

	point1.Print()
	point2.Print()

playWithPathMethods()
