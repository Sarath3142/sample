
package main

import "fmt"

//__________________________________________________________

func playWithArrayAndSlices() {
	a := [...]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 }
	fmt.Println("Array a: ", a)
	fmt.Printf("Array Type: %T\n", a)

	some1 := a[ 0 : 4 ]
	fmt.Println("Slice some1: ", some1 )
	fmt.Printf("Slice Type: %T\n", some1)
	fmt.Printf("Slice Len: %d Cap: %d\n", len(some1), cap(some1))

	some2 := a[ 4 : 9 ]
	fmt.Println("Slice some2: ", some2 )
	fmt.Printf("Slice Type: %T\n", some2)
	fmt.Printf("Slice Len: %d Cap: %d\n", len(some2), cap(some2))

	some3 := a[  : 5 ]
	fmt.Println("Slice some3: ", some3 )
	fmt.Printf("Slice Type: %T\n", some3)
	fmt.Printf("Slice Len: %d Cap: %d\n", len(some3), cap(some3))

	some4 := a[ 6 :  ]
	fmt.Println("Slice some4: ", some4 )
	fmt.Printf("Slice Type: %T\n", some4)
	fmt.Printf("Slice Len: %d Cap: %d\n", len(some4), cap(some4))

	some5 := a[ : ]
	fmt.Println("Slice some5: ", some5 )
	fmt.Printf("Slice Type: %T\n", some5)
	fmt.Printf("Slice Len: %d Cap: %d\n", len(some5), cap(some5))
}

//__________________________________________________________
// In Go
//		By Default Arrays Are Pass By Value

// In C/C++/Java/Python
//		By Default Arrays Are Pass By Reference

func changeArray( some [5]int ) {
	fmt.Println("Inside changeArray:: some: ", some)	
	for index, _ := range some {
		some[ index ] = 99
	}
	fmt.Println("Inside changeArray:: some: ", some)	
}

func changeArrayAgain( some [5]int ) {
	var someNew [5]int = [5]int{ 11, 11, 11, 11, 11 }
	some = someNew
}

// Array Pass By Reference Using Reference
func changeArrayMore( someAddress *[5]int ) {
	for index, _ := range someAddress {
		someAddress[ index ] = 99
	}
}

// Array Pass By Reference Using Slice
func changeArrayOnceMore( someSlice []int ) {
	for index, _ := range someSlice {
		someSlice[ index ] = 88
	}
}

func playWithArrayAndSlicessAgain() {
	var numbers [5]int = [5]int{ 10, 20, 30, 40, 50 }
	fmt.Println("Numbers: ", numbers)
	changeArray( numbers )
	fmt.Println("Numbers: ", numbers)
	changeArrayAgain( numbers )
	fmt.Println("Numbers: ", numbers)
	changeArrayMore( &numbers ) // Passing Address/Reference Of Array
	fmt.Println("Numbers: ", numbers)
	changeArrayOnceMore( numbers[ : ] ) // Passing Slice Of Array
	fmt.Println("Numbers: ", numbers)
}
// Function: playWithArraysOnceAgain
// Numbers:  [10 20 30 40 50]
// Numbers:  [10 20 30 40 50]
// Numbers:  [10 20 30 40 50]
// Numbers:  [99 99 99 99 99]

//__________________________________________________________

func playWithArrays() {
	var numbers [5]int = [5]int { 10, 20, 30, 40, 50 }
	// Array Assignment i.e. It's Value Assignment
	numbersCopy := numbers

	fmt.Println("Numbers: ", numbers)
	fmt.Println("numbersCopy: ", numbersCopy)

	numbers[0] = 99
	fmt.Println("Numbers: ", numbers)
	fmt.Println("numbersCopy: ", numbersCopy)
}

//__________________________________________________________

func reverse( s []int ) {
	for i, j := 0, len( s ) - 1 ; i < j ; i, j = i + 1, j - 1 {// i++, j-- {
		s[i], s[j] = s[j], s[i]
	}
}

func playWithArraysAndSlices() {
	a := [...]int{10, 20, 30, 40, 50, 60, 70, 80, 90, 99}
	fmt.Println("Array a: ", a)

	some1 := a[ 0 : 4 ]
	reverse( some1 )
	fmt.Println("Array a: ", a)

	some2 := a[ 4 : 9 ]
	reverse( some2 )
	fmt.Println("Array a: ", a)

	some3 := a[  :  ]
	reverse( some3 )
	fmt.Println("Array a: ", a)
}

//__________________________________________________________

func printCommon( summer []string, quater []string ) {
	for _, summerMonth := range summer {
		for _, quaterMonth := range quater {
			if summerMonth == quaterMonth {
				fmt.Printf("%s Month Appear In Both!", summerMonth  )
			}
		}
	}
}

// func slicesEqual( x []string, y []string ) bool
func slicesEqual( x, y []string ) bool {
	if len( x ) != len( y ) { return false }

	for index := range x {
		if x[index] != y[index] { return false }
	}

	return true
}

func playWithSlices() {
	months := [...]string {
		1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun",
		7: "Jul", 8: "Aug", 9: "Sep", 10:"Oct", 11:"Nov", 12:"Dec",
	}

	quater2 := months[ 4 : 7 ]
	summers := months[ 6 : 9 ]
	fmt.Println( months )
	fmt.Println( quater2 )
	fmt.Println( summers )	
	printCommon( summers, quater2 )

	firstThree := months[ 1 : 4 ]
	quater1    := months[ 1 : 4]
	// invalid operation: firstThree == quater1 
	//		(slice can only be compared to nil)
	// equalResult := firstThree == quater1
	equalResult := slicesEqual( firstThree, quater1 )
	fmt.Println(equalResult)
}


//________________________________________________________________
// 				GO SLICES CONCEPTS
//________________________________________________________________
/*
Slices represent variable-length sequences whose elements all have the same type. 
	A slice type is written []T, where the elements have type T; 
		it looks like an array type without a size.

A slice is a lightweight data structure that gives access to a subsequence 
(or perhaps all) of the elements of an array, which is known as the 
slice’s underlying array. 

	A slice has three components: a pointer, a length, and a capacity. 
		The pointer points to the first element of the array that is 
         reachable through the slice, which is not necessarily the array’s 
         first element. 
		The length is the number of slice elements; it can’t exceed the capacity, 
			which is usually the number of elements between 
			the start of the slice and the end of the underlying array. 
		The built-in functions len and cap return those values.


The slice operator s[ i : j ], where 0 ≤ i ≤ j ≤ cap(s), 
	Creates a new slice that refers to elements i through j-1 of the sequence s, 
	which may be an array variable, a pointer to an array, or anotherslice. 
	The resulting slice has j-i elements. 
	If i is omitted,it’s 0,and if j isomitted, it’s len(s). 

	Thus the slice months[1:13] refers to the whole range of valid months, 
	as does the slice months[1:]; the slice months[:] refers to the whole array.
*/
//__________________________________________________________

func playWithSlicesAgain() {
	s := make( []string, 3 )
	fmt.Println("Slice: ", s)
	fmt.Printf("Slice Type: %T\n", s)
	fmt.Printf("Slice Length and Capacity: %d %d\n", len(s), cap(s))

	ss := make( []int, 3 )
	fmt.Println("Slice: ", ss)
	fmt.Printf("Slice Type: %T\n", ss)
	fmt.Printf("Slice Length and Capacity: %d %d\n", len(ss), cap(ss))

	s[0] = "Ding"
	s[1] = "Ting"
	s[2] = "Tong"

	fmt.Println("Slice: ", s)
	fmt.Printf("Slice Length and Capacity: %d %d\n", len(s), cap(s))

	s = append( s, "Ming" )
	fmt.Println("Slice: ", s)
	fmt.Printf("Slice Length and Capacity: %d %d\n", len(s), cap(s))	

	s = append( s, "Mong", "Dong" )
	fmt.Println("Slice: ", s)
	fmt.Printf("Slice Length and Capacity: %d %d\n", len(s), cap(s))	

	s = append( s, "Bong" )
	fmt.Println("Slice: ", s)
	fmt.Printf("Slice Length and Capacity: %d %d\n", len(s), cap(s))	

	s = append( s, "Modi" )
	fmt.Println("Slice: ", s)
	fmt.Printf("Slice Length and Capacity: %d %d\n", len(s), cap(s))		
}

//__________________________________________________________

func playWithSlicesAgain1() {
	ss := make( []int, 3 )
	fmt.Println("Slice: ", ss)
	fmt.Printf("Slice Type: %T\n", ss)
	fmt.Printf("Slice Length and Capacity: %d %d\n", len(ss), cap(ss))

	ss[0] = 10
	ss[1] = 20
	ss[2] = 30

	fmt.Println("Slice: ", ss)
	fmt.Printf("Slice Length and Capacity: %d %d\n", len(ss), cap(ss))

	ss = append( ss, 99 )
	fmt.Println("Slice: ", ss)
	fmt.Printf("Slice Length and Capacity: %d %d\n", len(ss), cap(ss))	
}

//__________________________________________________________

func playWithSlicesOnceAgain() {
	// In Go Arrays In Value Type
	// In C/C++/Java/Python Arrays Are Reference Type
	numbers := [...]int{ 10, 20, 30, 40, 50, 60 }
	// In Go Array Asignment Is Value Assignemnt
	// In C/C++/Java Array Assignment Is Reference Assignment
	numbersCopy := numbers // Value Assignment

	fmt.Println("numbers: ", numbers)
	fmt.Println("numbersCopy: ", numbersCopy)
	numbers[ 0 ] = 99
	fmt.Println("numbers: ", numbers)
	fmt.Println("numbersCopy: ", numbersCopy)

	some := numbers[ 0 : 3 ]
	fmt.Println("some Slice: ", some)
	fmt.Printf("some Slice Length and Capacity: %d %d\n", len(some), cap(some))		

	some = append( some, 99 )
	fmt.Println("some Slice: ", some)
	fmt.Printf("some Slice Length and Capacity: %d %d\n", len(some), cap(some))		
	fmt.Println("numbers: ", numbers)
	fmt.Printf("numbers Array Length and Capacity: %d %d\n", 
										len(numbers), cap(numbers))
	fmt.Println("numbersCopy: ", numbersCopy)
	fmt.Printf("numbersCopy Array Length and Capacity: %d %d\n", 										
									len(numbersCopy), cap(numbersCopy))

	some = append( some, 88, 77 )
	fmt.Println("some Slice: ", some)
	fmt.Printf("some Slice Length and Capacity: %d %d\n", len(some), cap(some))		
	fmt.Println("numbers: ", numbers)
	fmt.Printf("numbers Array Length and Capacity: %d %d\n", 
										len(numbers), cap(numbers))
	fmt.Println("numbersCopy: ", numbersCopy)
	fmt.Printf("numbersCopy Array Length and Capacity: %d %d\n", 										
									len(numbersCopy), cap(numbersCopy))

	some = append( some, 66 )
	fmt.Println("some Slice: ", some)
	fmt.Printf("some Slice Length and Capacity: %d %d\n", len(some), cap(some))		
	fmt.Println("numbers: ", numbers)
	fmt.Printf("numbers Array Length and Capacity: %d %d\n", 
										len(numbers), cap(numbers))
	fmt.Println("numbersCopy: ", numbersCopy)
	fmt.Printf("numbersCopy Array Length and Capacity: %d %d\n", 										
									len(numbersCopy), cap(numbersCopy))

}

//__________________________________________________________

func playWithSlicesOnceAgain1() {
	numbers := [...]int{ 10, 20, 30, 40, 50, 60 }
	numbersCopy := numbers // Value Assignment

	fmt.Println("numbers: ", numbers)
	fmt.Println("numbersCopy: ", numbersCopy)
	numbers[ 0 ] = 99
	fmt.Println("numbers: ", numbers)
	fmt.Println("numbersCopy: ", numbersCopy)

	some := numbers[ 0 : 3 ]
	fmt.Println("some Slice: ", some)
	fmt.Printf("some Slice Length and Capacity: %d %d\n", len(some), cap(some))		

	some = append( some, 99 )
	fmt.Println("some Slice: ", some)
	fmt.Printf("some Slice Length and Capacity: %d %d\n", len(some), cap(some))		
	fmt.Println("numbers: ", numbers)
	fmt.Printf("numbers Array Length and Capacity: %d %d\n", 
										len(numbers), cap(numbers))
	someCopy := some 
	someCopy[0] = 777
	fmt.Println("some Slice: ", some)
	fmt.Println("some Slice: ", someCopy)
	fmt.Println("numbers: ", numbers)
	fmt.Println("numbersCopy: ", numbersCopy)
}

//__________________________________________________________

func playWithSlicesMore() {
	// In Go Slices Are Reference Type
	ss := make( []int, 4 )
	ss[0] = 10
	ss[1] = 20
	ss[2] = 30
	ss[3] = 40

	cc := make( []int, len(ss) )

	fmt.Println("ss : ", ss)
	fmt.Println("cc : ", cc)
	//Shallow Copy
	cc = ss // Reference Assignment
	fmt.Println("ss : ", ss)
	fmt.Println("cc : ", cc)

	ss[3] = 777
	fmt.Println("ss : ", ss)
	fmt.Println("cc : ", cc)

	dd := make( []int, len(ss) )
	copy( dd, ss ) // Deep Copys

	fmt.Println("ss : ", ss)
	fmt.Println("dd : ", dd)
	ss[3] = 999
	fmt.Println("ss : ", ss)
	fmt.Println("dd : ", dd)
}

//__________________________________________________________

func appendInt( x []int, y int ) []int {
	var z []int

	zlen := len( x ) + 1
	if zlen <= cap( x ) {
		z = x [ : zlen ]
	} else {
		zcap := zlen
		if zcap < 2 * len( x ) {
			zcap = 2 * len( x )
		}

		z = make( []int, zlen, zcap )
		copy( z, x )
	}
	z[ len( x ) ] = y
	return z
}

func playWithAppendInt() {
	var x, y []int

	for i := 0 ; i < 10 ; i++ {
		y = appendInt(x, i)
		fmt.Printf("%d Capacity = %d \t %v \n", i, cap( y ), y )
		x = y
	}
}

//__________________________________________________________
// Polymorphic Function
//		Using Mechanims: Varidiac Function

// Varidiac Function
//		Function With Variable Number Of Arguments
func summation( numbers ...int ) int {
	total := 0

	for _, number := range numbers {
		total = total + number
	}
	return total
}

func playWithSummation() {
	var result int

	result = summation()
	fmt.Println("Result:", result)

	result = summation(10, 20)
	fmt.Println("Result:", result)

	result = summation(10, 20, 30, 40, 50)
	fmt.Println("Result:", result)

	result = summation(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)
	fmt.Println("Result:", result)

	numbers := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	result = summation( numbers... )
	fmt.Println("Result:", result)
}

//__________________________________________________________


func appendSlice( x []int, y ...int ) []int {
	var z []int

	zlen := len( x ) + len ( y )
	if zlen <= cap( x ) {
		z = x [ : zlen ]
	} else {
		zcap := zlen
		if zcap < 2 * len( x ) {
			zcap = 2 * len( x )
		}

		z = make( []int, zlen, zcap )
		copy( z, x )
	}
	copy( z[ len( x ) : ], y )
	return z
}

func playWithAppendSlices() {
	var x, y []int

	for i := 0 ; i < 10 ; i++ {
		y = appendSlice(x, i)
		fmt.Printf("%d Capacity = %d \t %v \n", i, cap( y ), y )
		x = y
	}
	fmt.Println( x )

	x = appendSlice(x, 10, 20, 30)
	// fmt.Println( x )
	fmt.Printf("Length: %d, Capacity: %d Value:%v \n", len(x), cap(x), x )

	x = appendSlice(x, 11, 22, 33, 44, 55, 66)
	// fmt.Println( x )
	fmt.Printf("Length: %d, Capacity: %d Value:%v \n", len(x), cap(x), x )

	numbers := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	x = appendSlice(x, numbers...)
	// fmt.Println( x )
	fmt.Printf("Length: %d, Capacity: %d Value:%v \n", len(x), cap(x), x )
}

//__________________________________________________________

func filterEmpty( strings []string ) []string {
	i := 0
	for _, s := range strings {
		if s != "" {
			strings[i] = s
			i++
		}
	}
	return strings[ : i ]
}

func filterEmptyAgain( strings []string ) []string {
	out := strings[ : 0 ]
	for _, s := range strings {
		if s != "" {
			out = append( out, s)
		}
	}
	return out
}

func playWithFilterEmpty() {
	data := []string{ "one", "", "three", "four", "", "nice"}
	fmt.Printf(" %q \n", data )
	filteredData := filterEmpty( data )
	fmt.Printf(" %q \n", filteredData )

	dataAgain := []string{ "one", "", "three", "four", "", "nice"}
	fmt.Printf(" %q \n", dataAgain )
	filteredDataAgain := filterEmpty( dataAgain )
	fmt.Printf(" %q \n", filteredDataAgain )
}

//__________________________________________________________

func playWithSomething() {
	something := make( [][]int, 3 )

	for i := 0 ; i < 3 ; i++ {
		innerLen := i + 1
		something[i] = make( []int, innerLen )

		for j := 0 ; j < innerLen ; j++ {
			something[i][j] = i + j
		}

	}

	fmt.Println( something )
}

//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

func main() {
	fmt.Println("\nFunction: playWithArrayAndSlices")
	playWithArrayAndSlices()

	fmt.Println("\nFunction: playWithArrayAndSlicessAgain")
	playWithArrayAndSlicessAgain()

	fmt.Println("\nFunction: playWithArrays")
	playWithArrays()

	fmt.Println("\nFunction: playWithArraysAndSlices")
	playWithArraysAndSlices()

	fmt.Println("\nFunction: playWithSlices")
	playWithSlices()

	fmt.Println("\nFunction: playWithSlicesAgain")
	playWithSlicesAgain()

	fmt.Println("\nFunction: playWithSlicesAgain1")
	playWithSlicesAgain1()

	fmt.Println("\nFunction: playWithSlicesOnceAgain")
	playWithSlicesOnceAgain()

	fmt.Println("\nFunction: playWithSlicesOnceAgain1")
	playWithSlicesOnceAgain1()

	fmt.Println("\nFunction: playWithSlicesMore")
	playWithSlicesMore()

	fmt.Println("\nFunction: playWithAppendInt")
	playWithAppendInt()

	fmt.Println("\nFunction: playWithSummation")
	playWithSummation()

	fmt.Println("\nFunction: playWithAppendSlices")
	playWithAppendSlices()

	fmt.Println("\nFunction: playWithFilterEmpty")
	playWithFilterEmpty()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}

/*
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
*/

