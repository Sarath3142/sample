
#include <stdio.h>

int main( int argc, char * argv[] ) {
	
	if( argc == 1 ) {
		printf("\nNo Extra Arguments Supplied");
	}
		
	if (argc >= 2 ) {
		printf("\nCommand Line Arguments Supplied:\n");
		for ( int i = 0 ; i < argc ; i++ ) {
			printf("\n\t%d Argument : %s ", i, argv[i]);
		}
	}

	printf("\nEntering Infinte Loop");
	printf("\n");

	while( 1 );
	printf("\nExiting Infinte Loop");
}
