
package main

import (
	"fmt"
	"bufio"
	"os"
)
//________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE YOUR HANDS!!!

// Maps Is Collection Of Key and Value Pairs
//	Map Syntax : map[ KeyType ]ValueType

func playWithMaps() {
    m := make( map[string]int )

    m["k1"] = 7  	// Storing 7 Value For Key "k1"
    m["k2"] = 13	// Storing 13 Value For Key "k2"

    fmt.Println("map:", m)

    v1 := m["k1"] 	// Getting Value For Key "k1"
    fmt.Println("v1: ", v1)

    fmt.Println("len:", len(m))

    delete(m, "k2")  // Deleting Key "k2" : Will Delete Key, Value Pair
    fmt.Println("map:", m)

    _, prs := m["k2"]  // Getting Value For Key "k2"
    fmt.Println("prs:", prs)

    // Declarative Syntax
    // 	To Create Map With Initialisation List
    n := map[string]int{"foo": 1, "bar": 2}
    fmt.Println("map:", n)
}

//________________________________________________________________

// create and initialize maps
func playWithMaps1() {
	// Creating and initializing empty map
	// Using var keyword
	var map_1 map[int]int

	// Checking if the map is nil or not
	if map_1 == nil {
	
		fmt.Println("True")
	} else {
	
		fmt.Println("False")
	}

	// Creating and initializing a map
	// Using shorthand declaration and
	// using map literals
	map_2 := map[int]string{
	
			90: "Dog",
			91: "Cat",
			92: "Cow",
			93: "Bird",
			94: "Rabbit",
	}
	
	fmt.Println("Map-2: ", map_2)
}

//________________________________________________________________

// create and initialize a map
// Using make() function

func playWithMaps2() {
	// Creating a map
	// Using make() function
	var My_map = make(map[float64]string)
	fmt.Println(My_map)

	// As we already know that make() function
	// always returns a map which is initialized
	// So, we can add values in it
	My_map[1.3] = "Rohit"
	My_map[1.5] = "Sumit"
	fmt.Println(My_map)
}

//________________________________________________________________

// To iterate the map using for range loop
func playWithMaps3() {
	// Creating and initializing a map
	m_a_p := map[int]string{
		90: "Dog",
		91: "Cat",
		92: "Cow",
		93: "Bird",
		94: "Rabbit",
	}

	// Iterating map using for range loop
	for id, pet := range m_a_p {
		fmt.Println(id, pet)
	}
}

//________________________________________________________________

// a key-value pair in the map using make() function
func playWithMaps4() {
	// Creating and initializing a map
	m_a_p := map[int]string{
		90: "Dog",
		91: "Cat",
		92: "Cow",
		93: "Bird",
		94: "Rabbit",
	}

	fmt.Println("Original map: ", m_a_p)

	// Adding new key-value pairs in the map
	m_a_p[95] = "Parrot"
	m_a_p[96] = "Crow"
	fmt.Println("Map after adding new key-value pair:\n", m_a_p)

	// Updating values of the map
	m_a_p[91] = "PIG"
	m_a_p[93] = "DONKEY"
	fmt.Println("\nMap after updating values of the map:\n", m_a_p)
}

//________________________________________________________________

// retrieve the value of the key
func playWithMaps5() {
	// Creating and initializing a map
	m_a_p := map[int]string{
		90: "Dog",
		91: "Cat",
		92: "Cow",
		93: "Bird",
		94: "Rabbit",
	}
	fmt.Println("Original map: ", m_a_p)

	// Retrieving values with the help of keys
	value_1 := m_a_p[90]
	value_2 := m_a_p[93]
	fmt.Println("Value of key[90]: ", value_1)
	fmt.Println("Value of key[93]: ", value_2)
}

//________________________________________________________________

// check the key is available or not
func playWithMaps6() {
	// Creating and initializing a map
	m_a_p := map[int]string{
		90: "Dog",
		91: "Cat",
		92: "Cow",
		93: "Bird",
		94: "Rabbit",
	}

	fmt.Println("Original map: ", m_a_p)

	// Checking the key is available
	// or not in the m_a_p map
	pet_name, ok := m_a_p[90]
	fmt.Println("\nKey present or not:", ok)
	fmt.Println("Value:", pet_name)

	// Using blank identifier
	_, ok1 := m_a_p[92]
	fmt.Println("\nKey present or not:", ok1)
}

//________________________________________________________________

// Go program to illustrate how to delete a key
func playWithMaps7() {
	// Creating and initializing a map
	m_a_p := map[int]string{
		90: "Dog",
		91: "Cat",
		92: "Cow",
		93: "Bird",
		94: "Rabbit",
	}

	fmt.Println("Original map: ", m_a_p)

	// Deleting keys
	// Using delete function
	delete(m_a_p, 90)
	delete(m_a_p, 93)

	fmt.Println("Map after deletion: ", m_a_p)
}

//________________________________________________________________

// modification concept in map
func playWithMaps8() {
	// Creating and initializing a map
	m_a_p := map[int]string{
		90: "Dog",
		91: "Cat",
		92: "Cow",
		93: "Bird",
		94: "Rabbit",
	}
	fmt.Println("Original map: ", m_a_p)

	// Assigned the map into a new variable
	new_map := m_a_p

	// Perform modification in new_map
	new_map[96] = "Parrot"
	new_map[98] = "Pig"

	// Display after modification
	fmt.Println("New map: ", new_map)
	fmt.Println("\nModification done in old map:\n", m_a_p)
}

//________________________________________________________________

// Map Are References
func playWithMaps9() {
  var a = map[string]string{"brand": "Ford", "model": "Mustang", "year": "1964"}
  b := a

  fmt.Println(a)
  fmt.Println(b)

  b["year"] = "1970"
  fmt.Println("After change to b:")

  fmt.Println(a)
  fmt.Println(b)
}


//________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE YOUR HANDS!!!

func removeDuplicates() {
	seen := make(map[string]bool) // a set of strings
	input := bufio.NewScanner(os.Stdin)
	for input.Scan() {
		line := input.Text()
		if !seen[line] {
			seen[line] = true
			fmt.Println(line)
		}
	}

	if err := input.Err(); err != nil {
		fmt.Fprintf(os.Stderr, "removeDuplicates: %v\n", err)
		os.Exit(1)
	}	

	fmt.Println( seen )
}

//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

func main() {
	fmt.Println("\nFunction: playWithMaps")
	playWithMaps()

	fmt.Println("\nFunction: playWithMaps1")
	playWithMaps1()

	fmt.Println("\nFunction: playWithMaps2")
	playWithMaps2()

	fmt.Println("\nFunction: playWithMaps3")
	playWithMaps3()

	fmt.Println("\nFunction: playWithMaps4")
	playWithMaps4()

	fmt.Println("\nFunction: playWithMaps5")
	playWithMaps5()

	fmt.Println("\nFunction: playWithMaps6")
	playWithMaps6()

	fmt.Println("\nFunction: playWithMaps7")
	playWithMaps7()

	fmt.Println("\nFunction: playWithMaps8")
	playWithMaps8()

	// fmt.Println("\nFunction: removeDuplicates")
	// removeDuplicates()
	
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}


