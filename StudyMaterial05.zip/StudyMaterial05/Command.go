
package main

import (
	"fmt"
	"os"
)

//____________________________________________

func playWithCommandLineArguments() {
	var args = os.Args

	for i := 0 ; i < len( args ) ; i++ {
		fmt.Printf("\n\t %d Argument : %s", i, args[i])
	}
}

//____________________________________________

func playWithCommandLineArgumentsAgain() {
	var argsSupplied, seperator string
	seperator = "\n"
	var args = os.Args

	for i := 0 ; i < len( args ) ; i++ {
		argsSupplied = argsSupplied + seperator + args[i]
	}

	fmt.Println( argsSupplied )
}

//____________________________________________
//____________________________________________
//____________________________________________

func main() {
	fmt.Println("\nFunction: playWithCommandLineArguments")
	playWithCommandLineArguments()

	// fmt.Println("\nFunction: playWithCommandLineArgumentsAgain")
	// playWithCommandLineArgumentsAgain()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")	
}


https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/

