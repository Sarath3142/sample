
package model

import "fmt"

func saySomething() {
	fmt.Println("Hello Model!!!")
}

func SaySomething() {
	fmt.Println("Hello Model!!!")
}
