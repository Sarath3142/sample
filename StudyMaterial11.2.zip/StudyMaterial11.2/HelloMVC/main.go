
package main

import (
	"example.com/mvc/controller"
	"example.com/mvc/model"
	"example.com/mvc/view"
)

func main() {
/*
	controller.saySomething()
	model.saySomething()
	view.saySomething()
*/

	controller.SaySomething()
	model.SaySomething()
	view.SaySomething()
}

