
package main

import "fmt"
import "log"

//________________________________________________________________

func sumInts( m map[string]int64 ) int64 {
	var s int64
	for _, v := range m {
		s += v
	}
	return s
}

func sumFloats( m map[string]float64 ) float64 {
	var s float64
	for _, v := range m {
		s += v
	}
	return s
}

// Generics/Templates
//		It's A Code Which Will Generate Codes
//		By Subsituting Type At Compile Time
//		Type Placeholder Will Be Replaced With Type

// Here K and V Are Type Placeholders
//		K and V Will Be Substituted With Type At Compile Time
//		We Can Specify Type Bounds For Type PlaceHolders
//		e.g. 
//			K Type Plaeholder Have Type Bound
//				It Can Be Of Any Type Which Is Type Of Comparable
//			V Type Plaeholder Have Type Bounds
//				It Can Be Of Either int64 Or float64

// Polymorphism
//		It's Compile Time Polymorphism
//		Polymorphic Function: Using Mechanism Generics
func sumIntsOrFloats[K comparable, V int64|float64 ](m map[K]V ) V {
	var s V
	for _, v := range m {
		s += v
	}
	return s
}

//________________________________________________________________

type Number interface {
	int64 | float64 
}

func sumNumbers[K comparable, V Number ](m map[K]V ) V {
	var s V
	for _, v := range m {
		s += v
	}
	return s
}

//________________________________________________________________

func playWithGenerics() {
	someInts := map[string]int64 {
		"first": 34,
		"second": 12,
		"third": 10,
	}

	someFloats := map[string]float64 {
		"first": 34.1,
		"second": 12.2,
		"third": 10.3,
	}

	fmt.Printf("Sum Of Ints: %v\n", sumInts( someInts ) )
	fmt.Printf("Sum Of Floats: %v\n", sumFloats( someFloats ) )

	fmt.Printf("Sum Of Ints: %v\n", sumIntsOrFloats[string, int64]( someInts ) )
	fmt.Printf("Sum Of Floats: %v\n", sumIntsOrFloats[string, float64]( someFloats ) )

	// string does not satisfy int64 | float64 (string missing in int64 | float64)
	//		i.e. string Type Doesn't Satisfy Type Bounds
	// fmt.Printf("Sum Of Floats: %v\n", sumIntsOrFloats[string, string]( someFloats ) )

	fmt.Printf("Sum Of Ints: %v\n", sumNumbers[string, int64]( someInts ) )
	fmt.Printf("Sum Of Floats: %v\n", sumNumbers[string, float64]( someFloats ) )
}

//________________________________________________________________

func PrintS(s []string) {
    for _, v := range s {
        fmt.Print(v)
    }
    fmt.Println()
}

func PrintI(s []int) {
    for _, v := range s {
        fmt.Print(v)
    }
    fmt.Println()
}

func Print[T any](s []T) {
    for _, v := range s {
        fmt.Print(v)
    }
    fmt.Println()
}

func playWithGenericPrint() {
	PrintS( []string{ "Ding", "Dong", "Ting", "Tong"} )
	PrintI( []int{10, 20, 30, 22, 99, 77} )

	Print( []string{ "Ding", "Dong", "Ting", "Tong"} )
	Print( []int{10, 20, 30, 22, 99, 77} )
}


//________________________________________________________________

func Equal[T comparable](a, b T) bool {
    return a == b
}

func playWithGenericEqual() {
    fmt.Println( Equal("Ding","Ding") )
    fmt.Println( Equal("Ding","Dong") )

    fmt.Println( Equal( 99, 99 ) )
    fmt.Println( Equal( 99, 100 ) )
}

//________________________________________________________________

type PrintNum int
type PrintText string

type PrintInterface interface {
	print()
}

func (p PrintNum) print() {
	log.Println("Num:", p)
}

func (p PrintText) print() {
	log.Println("Text:", p)
}

// PrintSlice prints elements of a slice of any type
func PrintSlice[T PrintInterface](s []T) {
	for _, value := range s {
		value.print()
	}
}

func playWithGenericPrintSlice() {
	// Example with PrintSlice
	stringSlice := []PrintText{"apple", "banana", "orange"}
	intSlice := []PrintNum{5, 2, 9, 1, 7}

	fmt.Println("String slice:")
	PrintSlice(stringSlice)

	fmt.Println("\nInteger slice:")
	PrintSlice(intSlice)
}

//________________________________________________________________


// Polymorphism
//		It's Compile Time Polymorphism
//		Polymorphic Stack Type: Using Mechanism Generics
// Stack is a generic stack data structure.
type Stack[T any] struct {
	items []T
}

// Push adds an element to the top of the stack.
func (s *Stack[T]) Push(item T) {
	s.items = append(s.items, item)
}

// Pop removes and returns the element from the top of the stack.
func (s *Stack[T]) Pop() (T, error) {
	if len(s.items) == 0 {
		var zeroValue T
		return zeroValue, fmt.Errorf("stack is empty")
	}
	item := s.items[len(s.items)-1]
	s.items = s.items[:len(s.items)-1]
	return item, nil
}

// Size returns the number of elements in the stack.
func (s *Stack[T]) Size() int {
	return len(s.items)
}

func playWithGenericStack() {
	// Example with integers
	intStack := Stack[int]{}
	intStack.Push(1)
	intStack.Push(2)
	intStack.Push(3)

	fmt.Println("Int Stack Size:", intStack.Size())

	poppedInt, err := intStack.Pop()
	if err == nil {
		fmt.Println("Popped Int:", poppedInt)
	}

	// Example with strings
	stringStack := Stack[string]{}
	stringStack.Push("apple")
	stringStack.Push("banana")
	stringStack.Push("cherry")

	fmt.Println("String Stack Size:", stringStack.Size())

	poppedString, err := stringStack.Pop()
	if err == nil {
		fmt.Println("Popped String:", poppedString)
	}
}

//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

func main() {
	fmt.Println("\nFunction: playWithGenerics")
	playWithGenerics()

	fmt.Println("\nFunction: playWithGenericPrint")
	playWithGenericPrint()

	fmt.Println("\nFunction: playWithGenericEqual")
	playWithGenericEqual()

	fmt.Println("\nFunction: playWithGenericPrintSlice")
	playWithGenericPrintSlice()

	fmt.Println("\nFunction: playWithGenericStack")
	playWithGenericStack()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}


/*
_____________________________________________________________________
// Go Generics Tutorial
	https://www.digitalocean.com/community/tutorials/how-to-use-generics-in-go
_____________________________________________________________________
Codebunk Link:

https://codebunk.com/b/7211100682491/
https://codebunk.com/b/7211100682491/
_____________________________________________________________________
*/

