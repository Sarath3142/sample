package main

import (
	"fmt"
	"time"
	"sync"
)

//__________________________________________________________

func doSomething( from string ) {
	for i := 0 ; i < 3 ; i++ {
		fmt.Println( from, " : ", i)
		time.Sleep( time.Second * 2 )
	}
}

func playWithGoRoutines() {
	fmt.Println( time.Now().Format( time.RFC850 ) )

	go doSomething("Oyee Hoyee!!!")
	go doSomething("Ye Dil Maaangeee More!!!")

	go func( message string ) {
		for i := 0 ; i < 3 ; i++ {
			fmt.Println( message, " : ", i)
			time.Sleep( time.Second * 2 )
		}	
		time.Sleep( time.Second * 3 )				
	}("Balleeee Baalleee!!!")

	fmt.Println( time.Now().Format( time.RFC850 ) )

	time.Sleep( time.Second * 6 )				
	fmt.Println("Done: playWithGoRoutines")
}


//__________________________________________________________

func playWithChannels() {
	messages := make( chan string )
	var messageRead string

	// <- Symbol Behind Channel Means Writing To Channel
	// <- Symbol Before Channel Means Reading From Channel	
	go func() {
		//Writing To Channel
		messages <- "Ping"
		time.Sleep( time.Second * 2 )

		messages <- "Pong"
		time.Sleep( time.Second * 2 )

		messages <- "Ting"
		time.Sleep( time.Second * 2 )

		messages <- "Tong"
		time.Sleep( time.Second * 2 )
		fmt.Println("Done: Closure Go Routine")
	}()

	messageRead = <- messages
	fmt.Println( messageRead )

	messageRead = <- messages
	fmt.Println( messageRead )

	messageRead = <- messages
	fmt.Println( messageRead )

	messageRead = <- messages
	fmt.Println( messageRead )

	fmt.Println("Done: playWithChannels")
}

//__________________________________________________________

func sum( numbers[] int, message chan int ) {
	result := 0
	for _, number := range numbers {
		result += number
	}
	message <- result
}

func playWithSum() {
	numbers := []int{ 1, 2, 3, 4, 5, 6, 7, 8, 9, -8, -9 }
	message := make( chan int )

	go sum( numbers[ : len( numbers ) / 2 ], message  )
	go sum( numbers[ len( numbers ) / 2 : ], message  )

	sum1, sum2 := <- message, <- message
	// sum1 := <- message
	// sum2 := <- message

	total := sum1 + sum2
	fmt.Println("Total Sum: ", total )
}

//__________________________________________________________

// Argument pings is Write Only Channel
func ping( pings chan<- string, data string ) {
	// Writing To Channel pings
	pings <- data
}

// Argument pings is Read Only Channel
// Argument pongs is Write Only Channel
func pong( pings <-chan string, pongs chan<- string ) {
	// Reading From Channel pings
	data := <- pings
	pongs <- data
}

func playWSithChannelWithReadWriteOnly() {
	pings := make( chan string, 1 )
	pongs := make( chan string, 1 )

	ping( pings, "Ye Dil Maangeee More!!!!" )
	pong( pings, pongs )

	fmt.Println( <- pongs )
}

//__________________________________________________________

// One suggestion (made by Rob Pike) for concurrent programming 
// is don't (let computations) communicate by sharing memory, 
// (let them) share memory by communicating (through channels). 
// (We can view each computation as a goroutine in Go programming.)

func worker( done chan bool ) {
	fmt.Println("Worker: Working...")
	// Worker Doing Some Heavy Cacluation...
	time.Sleep( time.Second * 3 )
	fmt.Println("Worker: Work Done!!")	

	done <- true
}

func playWithWokers() {
	done := make( chan bool, 1 )

	go worker( done )

	workerStatus := <- done 
	fmt.Println("Worker Status: Work Done?: ", workerStatus)	
}

//__________________________________________________________

func playWithClosingChannel() {
	messages := make( chan string, 2 )
	messages <- "Oyee Hoyeee!!!"
	messages <- "Ye Dil Maaangeee More!!!"

	close( messages )

	// Can Use Loop To Read From Channel
	for message := range messages {
		fmt.Println( message )
	}
}

//________________________________________________________________

func fibonacci( count int, fibos chan int ) {
	x, y := 0, 1

	for i := 0 ; i < count ; i++ {
		fibos <- x
		x, y = y, x + y
	}
	close( fibos )
}

func playWithFibonaccis() {
	fibos := make( chan int, 10 )

	go fibonacci( cap( fibos ), fibos )

	for fibo := range fibos {
		fmt.Println( fibo )
	}
} 

//________________________________________________________________

func fibonacciAgain( fibos chan int, quit chan bool ) {
	x, y := 0, 1
	// var order bool
	for {
		select {
		case fibos <- x:
			x, y = y, x + y
		case order := <- quit:
			if order == true {
				fmt.Println("Fibonacci Quit!")
				return
			}
		}
	}
}

func playWithFibonaccisAgain() {
	fibos 	:= make( chan int, 10 )
	quit 	:= make( chan bool )

	go func() {
		for i := 0 ; i < 10 ; i++ {
			fmt.Println( <- fibos )
		}
		quit <- true
	}()
	fibonacciAgain( fibos, quit )
} 

//________________________________________________________________

func playWithTimeTick() {
	tick := time.Tick(100 * time.Millisecond)
	boom := time.After(500 * time.Millisecond)

	for {
		select {
		case <-tick:
			fmt.Println("tick.")
		case <-boom:
			fmt.Println("BOOM!")
			return
		default:
			fmt.Println("    .")
			time.Sleep(50 * time.Millisecond)
		}
	}
}

//________________________________________________________________

// import "sync"

// SafeCounter is safe to use concurrently.
type SafeCounter struct {
	mu sync.Mutex
	v  map[string]int
}

// Inc increments the counter for the given key.
func (c *SafeCounter) Inc(key string) {
	c.mu.Lock()
	// Lock so only one goroutine at a time can access the map c.v.
	c.v[key]++
	c.mu.Unlock()
}

// Value returns the current value of the counter for the given key.
func (c *SafeCounter) Value(key string) int {
	c.mu.Lock()
	// Lock so only one goroutine at a time can access the map c.v.
	defer c.mu.Unlock()
	return c.v[key]
}

func playWithSafeCounter() {
	safeCounter := SafeCounter{v: make(map[string]int)}
	
	for i := 0; i < 1000; i++ {
		go safeCounter.Inc("somekey")
	}

	time.Sleep(time.Second)
	fmt.Println( safeCounter.Value("somekey") )
}

//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

func main() {
	// fmt.Println("\nFunction: playWithGoRoutines")
	// playWithGoRoutines()

	// fmt.Println("\nFunction: playWithChannels")
	// playWithChannels()

	// fmt.Println("\nFunction: playWithSum")
	// playWithSum()

	// fmt.Println("\nFunction: playWSithChannelWithReadWriteOnly")
	// playWSithChannelWithReadWriteOnly()

	// fmt.Println("\nFunction: playWithWokers")
	// playWithWokers()

	// fmt.Println("\nFunction: playWithFibonaccis")
	// playWithFibonaccis()

	// fmt.Println("\nFunction: playWithFibonaccisAgain")
	// playWithFibonaccisAgain()

	fmt.Println("\nFunction: playWithSafeCounter")
	playWithSafeCounter()
	
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}

/*
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
*/
