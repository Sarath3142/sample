
package main

import (
	"fmt"
	"log"
	"example.com/greetings"
)

func main() {
	// message, err := greetings.Hello("")

	// message, err := greetings.Hello("Gabbar Singh")
	// if err != nil {
	// 	log.Fatal( err )
	// }
	// fmt.Println( message )

    // A slice of names.
    names := []string{"Gladys", "Samantha", "Darrin"}

    // Request greeting messages for the names.
    messages, err := greetings.Hellos(names)
    if err != nil {
        log.Fatal(err)
    }
    // If no error was returned, print the returned map of
    // messages to the console.
    fmt.Println(messages)
}

//_____________________________________________________
// https://codebunk.com/b/7211100682491/
// https://codebunk.com/b/7211100682491/

/*
//_____________________________________________________
// In hello Directory
go run hello.go

// In greetings Directory
go test
go test -v

// In hello Directory
go build

*/


