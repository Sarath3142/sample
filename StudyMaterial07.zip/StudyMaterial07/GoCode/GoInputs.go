
package main

import (
	"fmt"
	"os"
	"bufio"
	"strings"
	"strconv"
)

//________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE YOUR HANDS!!!

func removeDuplicates() {
	seen := make(map[string]bool) // a set of strings
	fmt.Println("seen Length: ", len( seen ) )

	input := bufio.NewScanner( os.Stdin )	
	for input.Scan() {
		line := input.Text()
		if !seen[line] {
			seen[line] = true
			fmt.Println(line)
		}
	}

	if err := input.Err(); err != nil {
		fmt.Fprintf(os.Stderr, "removeDuplicates: %v\n", err)
		os.Exit(1)
	}	

	fmt.Println( seen )
}

//________________________________________________________________

func reverse( s []int ) {
	for i, j := 0, len( s ) - 1 ; i < j ; i, j = i + 1, j - 1 {
		s[i], s[j] = s[j], s[i]
	}
}

func playWithReadingInputs() {
	input := bufio.NewScanner( os.Stdin )

	outer: 
		for input.Scan() {
			var ints []int
			for _, s := range strings.Fields( input.Text() ) {
				x, err := strconv.ParseInt( s, 10, 64 )

				if err != nil {
					fmt.Fprintln( os.Stderr, err )
					continue outer
				}
				ints = append( ints, int( x ) )
			}

			fmt.Printf( "%v\n", ints )
			reverse( ints )
			fmt.Printf( "%v\n", ints )
		}
}


//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

func main() {
	// fmt.Println("\nFunction: removeDuplicates")
	// removeDuplicates()

	fmt.Println("\nFunction: playWithReadingInputs")
	playWithReadingInputs()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}

/*
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
https://codebunk.com/b/9761100686072/
*/
