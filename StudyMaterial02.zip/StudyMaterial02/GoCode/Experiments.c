#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

//__________________________________________________________

typedef double Celsius;
typedef double Fahrenheit;

const Celsius BoilingC = 100.0;
const Celsius FreezingC = 0.0;
const Celsius AbsoluteZeroC = -273.15;
const Fahrenheit FreezingF = 0.05;

void playWithTypes() {
	double ff = 11.11, gg = 22.22;
	double rr = ff + gg;
	printf("\nResult: %f", rr );

	Celsius ffAgain = 11.11;
	Fahrenheit ggAgain = 22.22;
	// invalid operation: ffAgain + ggAgain 
	//		(mismatched types Celsius and Fahrenheit)
	double rrAgain0 = ffAgain + ggAgain;
	Celsius rrAgain1 = ffAgain + ggAgain;
	Fahrenheit rrAgain2 = ffAgain + ggAgain;

	printf("\nValues Again: %f %f", ffAgain, ggAgain );
	printf("\nResult Again: %f %f %f", rrAgain0, rrAgain1, rrAgain2 );
}

//__________________________________________________________

void playIntTypesData() {
	int some = 0;
	for ( ; some <= 32767 ; some++ ) {
		printf(": %d :");
	}
}

void playCharTypesData() {
	char some = 0;
	for ( ; some <= 127 ; some++ ) {
		printf(": %c %d :");
	}
}

//__________________________________________________________

void playWithArrays() {
	char username[100];
	char password[100];
	int a[10] = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 };

	int i = 0;
	for( i = 0 ; i < 10 ; i++ ) {
		printf(" %d ", a[i] );
	}

	int k = -10;
	// int k = sum(a, b);
	for( i = k ; i < 10 ; i++ ) {
		printf(" %d ", a[i] );
	}
}


//__________________________________________________________

// DESIGN 01 : BAD CODE 
// Write Following Function In C
int sum(int a, int b ) {
	return a + b;
}

void playWithSum() {
	int a = 2147483647;
	int b = 11;
	int result = 0;

	result = sum( a, b );
	printf("\nResult : %d", result);

	a = -2147483648;
	b = -11;
	result = sum( a, b );
	printf("\nResult : %d", result);
}

// Function: playWithSum
// Result : -2147483638
// Result : 2147483637
//__________________________________________________________
/*
// DESIGN 02 : BAD CODE 
int sum(int a, int b ) {
	long long result = a + b;
	return result
}

// DESIGN 03 : BAD CODE 
long long sum(int a, int b ) {
	long long result = a + b;
	return result
}

// DESIGN 04 : BAD CODE 
int sum(int a, int b ) {
	if INT_MIN <= a
		b <= INT_MAX
		int total = a + b
		if MIN <= total <= MAX
		else
			ERROR
	else
		ERROR
}
*/
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

// Write Following sum Function In C
//	 	It should return valid Arithmatic Sum
///		Or Print Can't Calculate Sum For Given Values

// total = a + b
// total - b = a 
// a > total - b, b > 0
//#include <limits.h>

int summation( int a, int b ) {
	if ( ( b > 0 ) && a > ( INT_MAX - b ) ||
		 ( b < 0 ) && a < ( INT_MIN - b )) {
		printf("\nCan't Calculate Sum");
		exit(1);
	} else {
		return a + b;
	}
}

void playWithSummation() {
	int a = 2147483647;
	int b = 11;
	int result = 0;

	result = summation( a, b );
	printf("\nResult : %d", result);

	a = -2147483648;
	b = -11;
	result = summation( a, b );
	printf("\nResult : %d", result);
}
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

int main() {
	printf("\nFunction: playWithTypes");
	playWithTypes();

	// printf("\nFunction: playIntTypesData");
	// playIntTypesData();

	// printf("\nFunction: playCharTypesData");
	// playCharTypesData();
	
	printf("\nFunction: playWithArrays");
	playWithArrays();

	printf("\nFunction: playWithSum");
	playWithSum();

	printf("\nFunction: playWithSummation");
	playWithSummation();

	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");	
}

