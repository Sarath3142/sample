#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

//__________________________________________________________

typedef double Celsius;
typedef double Fahrenheit;

const Celsius BoilingC = 100.0;
const Celsius FreezingC = 0.0;
const Celsius AbsoluteZeroC = -273.15;
const Fahrenheit FreezingF = 0.05;

void playWithTypes() {
	double ff = 11.11, gg = 22.22;
	double rr = ff + gg;
	printf("\nResult: %f", rr );

	Celsius ffAgain = 11.11;
	Fahrenheit ggAgain = 22.22;
	// invalid operation: ffAgain + ggAgain 
	//		(mismatched types Celsius and Fahrenheit)
	double rrAgain0 = ffAgain + ggAgain;
	Celsius rrAgain1 = ffAgain + ggAgain;
	Fahrenheit rrAgain2 = ffAgain + ggAgain;

	printf("\nValues Again: %f %f", ffAgain, ggAgain );
	printf("\nResult Again: %f %f %f", rrAgain0, rrAgain1, rrAgain2 );
}

//__________________________________________________________

void playIntTypesData() {
	int some = 0;
	for ( ; some <= 32767 ; some++ ) {
		printf(": %d :", some);
	}
}

void playCharTypesData() {
	char some = 0;
	for ( ; some <= 127 ; some++ ) {
		printf(": %c %d :", some, some);
	}
}

//__________________________________________________________

void playWithArrays() {
	char username[100];
	char password[100];
	int a[10] = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 };

	int i = 0;
	for( i = 0 ; i < 10 ; i++ ) {
		printf(" %d ", a[i] );
	}

	int k = -10;
	// int k = sum(a, b);
	for( i = k ; i < 10 ; i++ ) {
		printf(" %d ", a[i] );
	}
}


//__________________________________________________________

// DESIGN 01 : BAD CODE 
// Write Following Function In C
int sum1(int a, int b ) {
	return a + b;
}

void playWithSum() {
	int a = 2147483647;
	int b = 11;
	int result = 0;

	result = sum1( a, b );
	printf("\nResult : %d", result);

	a = -2147483648;
	b = -11;
	result = sum1( a, b );
	printf("\nResult : %d", result);
}

// Function: playWithSum
// Result : -2147483638
// Result : 2147483637
//__________________________________________________________
/*
// DESIGN 02 : BAD CODE 
int sum(int a, int b ) {
	long long result = a + b;
	return result
}

// DESIGN 03 : BAD CODE 
long long sum(int a, int b ) {
	long long result = a + b;
	return result
}

// DESIGN 04 : BAD CODE 
int sum(int a, int b ) {
	if INT_MIN <= a
		b <= INT_MAX
		int total = a + b
		if MIN <= total <= MAX
		else
			ERROR
	else
		ERROR
}
*/

//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

// Write Following sum Function In C
//	 	It should return valid Arithmatic Sum
///		Or Print Can't Calculate Sum For Given Values

// total = a + b
// total - b = a 
// a > total - b, b > 0
//#include <limits.h>

int summation( int a, int b ) {
	if ( ( b > 0 ) && a > ( INT_MAX - b ) ||
		 ( b < 0 ) && a < ( INT_MIN - b )) {
		printf("\nCan't Calculate Sum");
		exit(1);
	} else {
		return a + b;
	}
}

void playWithSummation() {
	int a = 2147483647;
	int b = 11;
	int result = 0;

	result = summation( a, b );
	printf("\nResult : %d", result);

	a = -2147483648;
	b = -11;
	result = summation( a, b );
	printf("\nResult : %d", result);
}

//__________________________________________________________

int sum(int a, int b) { return a + b; }
int sub(int a, int b) { return a - b; }
int mul(int a, int b) { return a * b; }

// Polymoprhic Function
//		Mechanims: Passing A Behaviour To Behaviour
//				   Passing A Function To Function
int calculator( int a, int b, int ( *operation )( int, int ) ) {
	return operation( a, b );
}

void playWithCalculator() {
	int a = 40;
	int b = 20;
	int result = 0;

	result = calculator( a, b, sum );
	printf("\nResult : %d", result );

	result = calculator( a, b, sub );
	printf("\nResult : %d", result );

	result = calculator( a, b, mul );
	printf("\nResult : %d", result );
}

//__________________________________________________________

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doHindiMovieDance() {
	printf("Kutto Ke Saamne Dance!!!");
}

void doDanceBabyDance() {
	printf("Dance Baby Dance!!!");
}

void playWithHuman() {
	printf("\n");
	Human gabbar = { 420, "Gabbar Singh", doDanceBabyDance };
	printf("ID  : %d\n", gabbar.id );
	printf("Name: %s\n", gabbar.name );
	gabbar.dance();

	Human basanti = { 100, "Basanti Taange Wali", doHindiMovieDance };
	printf("ID  : %d\n", basanti.id );
	printf("Name: %s\n", basanti.name );
	basanti.dance();
}


//__________________________________________________________

int breakDance() {
	printf("\nDoing Break Dance!");
	return 1;
}

void playWithFunctionPointer() {
	int (* dance)();
	dance = breakDance;

	int result = dance();
	printf("\nResult : %d", result );
}


//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

int main() {
	printf("\n\nFunction: playWithTypes");
	playWithTypes();

	// printf("\nFunction: playIntTypesData");
	// playIntTypesData();

	// printf("\nFunction: playCharTypesData");
	// playCharTypesData();
	
	printf("\n\nFunction: playWithArrays");
	playWithArrays();

	printf("\n\nFunction: playWithSum");
	playWithSum();

	// printf("\nFunction: playWithSummation");
	// playWithSummation();

	printf("\n\nFunction: playWithCalculator");
	playWithCalculator();

	printf("\n\nFunction: playWithHuman");
	playWithHuman();

	printf("\n\nFunction: playWithFunctionPointer");
	playWithFunctionPointer();

	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");	
}

