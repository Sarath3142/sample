
package main

import (
    "example.com/hello/first"
    "example.com/hello/second"
)

func main() {
    first.HelloDing()
    second.HelloDong()
}

