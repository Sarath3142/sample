#include <stdio.h>

//__________________________________________________________

typedef double Celsius;
typedef double Fahrenheit;

const Celsius BoilingC = 100.0;
const Celsius FreezingC = 0.0;
const Celsius AbsoluteZeroC = -273.15;
const Fahrenheit FreezingF = 0.05;

void playWithTypes() {
	double ff = 11.11, gg = 22.22;
	double rr = ff + gg;
	printf("\nResult: %f", rr );

	Celsius ffAgain = 11.11;
	Fahrenheit ggAgain = 22.22;
	// invalid operation: ffAgain + ggAgain 
	//		(mismatched types Celsius and Fahrenheit)
	double rrAgain0 = ffAgain + ggAgain;
	Celsius rrAgain1 = ffAgain + ggAgain;
	Fahrenheit rrAgain2 = ffAgain + ggAgain;

	printf("\nValues Again: %f %f", ffAgain, ggAgain );
	printf("\nResult Again: %f %f %f", rrAgain0, rrAgain1, rrAgain2 );
}

//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

int main() {
	printf("\nFunction: playWithTypes");
	playWithTypes();

	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");	
}

