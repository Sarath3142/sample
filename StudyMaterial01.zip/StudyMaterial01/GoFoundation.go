/*
To Directly Run Go Program
go run GoFoundation.go

To Generate Executable File From Go Program
go build GoFoundation.go

To Run Generated Go Command
./GoFoundation
*/
package main

import "fmt"

//__________________________________________________________

func helloWorld() {
	fmt.Println("Hello World!!!")
}

//__________________________________________________________

// Constant
const boilingF = 212.0
const boilingCentigrade = 100

// Variable
var ff = 99
var cc = 88

func fToC( f float64 ) float64 {
	return ( f  - 32 ) * 5 / 9
}

func playWithConstantsAndVariables() {
	var f = boilingF
	var c = ( f  - 32 ) * 5 / 9 

	fmt.Printf("\nBoiling Point: %g Farenheit:", f)
	fmt.Printf("\nBoiling Point: %g Centrigrade:", c)

	var boilingC = fToC( boilingF )
	fmt.Printf("\nBoiling Point: %g Centrigrade:", boilingC)

	const first, second = 99.99, 88.88
	fmt.Printf("\nFirst: %g, Second: %g", first, second)

	fmt.Printf("\nVariables Outside: %d %d", ff, cc )
}

//__________________________________________________________

type Celsius 	float64
type Fahrenheit float64

const (
	BoilingC 		Celsius = 100.0
	FreezingC 		Celsius = 0.0
	AbsoluteZeroC 	Celsius = -273.15
	FreezingF 		Fahrenheit = 0.05
)

func playWithTypes() {
	var ff, gg = 11.11, 22.22
	var rr = ff + gg
	fmt.Println("Result: ", rr )

	var ffAgain Celsius = 11.11
	var ggAgain Fahrenheit = 22.22
	// invalid operation: ffAgain + ggAgain 
	//		(mismatched types Celsius and Fahrenheit)
	var rrAgain = ffAgain + ggAgain

	fmt.Println("Values Again: ", ffAgain, ggAgain )
	fmt.Println("Result Again: ", rrAgain )
}

//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

func main() {
	fmt.Println("\nFunction: helloWorld")
	helloWorld()

	fmt.Println("\nFunction: playWithConstantsAndVariables")
	playWithConstantsAndVariables()

	fmt.Println("\nFunction: playWithTypes")
	playWithTypes()

	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
	// fmt.Println("\nFunction: ")
}


